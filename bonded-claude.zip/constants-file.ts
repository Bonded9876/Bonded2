// App Information
export const APP_NAME = 'Bonded';
export const APP_VERSION = '1.0.0';

// API Keys and Firebase Config
// Note: In production, you should use environment variables or a secure method
export const FIREBASE_CONFIG = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_STORAGE_BUCKET",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// Payment Constants
export const PAYMENT_AMOUNT = 3499;
export const PAYMENT_CURRENCY = 'HUF';
export const PAYMENT_AMOUNT_USD = 9.99;

// Default Topics
export const DEFAULT_TOPICS = [
  {
    id: 'creative',
    name: 'Creative Expression',
    description: 'For artists, musicians, writers, and all creative souls',
    icon: 'color-palette',
    color: '#9333ea',
    membersCount: 842
  },
  {
    id: 'active',
    name: 'Active Living',
    description: 'Connect through sports, fitness, and outdoor adventures',
    icon: 'bicycle',
    color: '#2563eb',
    membersCount: 1204
  },
  {
    id: 'knowledge',
    name: 'Knowledge Pursuit',
    description: 'For intellectually curious minds and lifelong learners',
    icon: 'book',
    color: '#d97706',
    membersCount: 763
  },
  {
    id: 'builders',
    name: 'Builders & Makers',
    description: 'From entrepreneurs to DIY enthusiasts and creators',
    icon: 'hammer',
    color: '#16a34a',
    membersCount: 591
  },
  {
    id: 'cultural',
    name: 'Cultural Connection',
    description: 'Explore cultures, travel, languages, and global perspectives',
    icon: 'globe',
    color: '#dc2626',
    membersCount: 679
  }
];

// Map Settings
export const DEFAULT_MAP_DELTA = 0.01;
export const MAX_NEARBY_DISTANCE_KM = 5;
export const LOCATION_UPDATE_INTERVAL = 60000; // 1 minute in milliseconds
export const LOCATION_DISTANCE_FILTER = 10; // Update if moved 10 meters

// Chat Settings
export const MESSAGE_EXPIRATION_HOURS = 24;
export const DEFAULT_CHAT_LOAD_LIMIT = 50;

// Referral Program
export const REFERRAL_REQUIRED_INVITES = 3;

// Navigation Routes
export const ROUTES = {
  // Auth Stack
  AUTH: 'Auth',
  ONBOARDING: 'Onboarding',
  LOGIN: 'Login',
  SIGNUP: 'Signup',
  FORGOT_PASSWORD: 'ForgotPassword',
  PAYMENT_INTRO: 'PaymentIntro',
  PAYMENT: 'Payment',
  PROFILE_SETUP: 'ProfileSetup',
  
  // Main Stack
  MAIN: 'Main',
  
  // Tab Navigator
  TABS: 'Tabs',
  MAP: 'Map',
  TOPICS: 'Topics',
  CHATS: 'Chats',
  MEETUPS: 'Meetups',
  PROFILE: 'Profile',
  
  // Secondary Screens
  CHAT_DETAIL: 'ChatDetail',
  TOPIC_DETAIL: 'TopicDetail',
  USER_PROFILE: 'UserProfile',
  SETTINGS: 'Settings',
  NOTIFICATIONS: 'Notifications',
  CREATE_TOPIC: 'CreateTopic',
  CREATE_MEETUP: 'CreateMeetup'
};
