import React from 'react';
import {
  StyleSheet,
  TouchableOpacity,
  Text,
  ActivityIndicator,
  StyleProp,
  ViewStyle,
  TextStyle,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import theme from '../../theme';

type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
type ButtonSize = 'small' | 'medium' | 'large';

interface ButtonProps {
  title: string;
  onPress: () => void;
  variant?: ButtonVariant;
  size?: ButtonSize;
  disabled?: boolean;
  loading?: boolean;
  fullWidth?: boolean;
  leftIcon?: keyof typeof Ionicons.glyphMap;
  rightIcon?: keyof typeof Ionicons.glyphMap;
  style?: StyleProp<ViewStyle>;
  textStyle?: StyleProp<TextStyle>;
}

const Button: React.FC<ButtonProps> = ({
  title,
  onPress,
  variant = 'primary',
  size = 'medium',
  disabled = false,
  loading = false,
  fullWidth = false,
  leftIcon,
  rightIcon,
  style,
  textStyle,
}) => {
  // Get button styles based on variant, size, and state
  const buttonStyle = [
    styles.button,
    styles[`${variant}Button`],
    styles[`${size}Button`],
    fullWidth && styles.fullWidth,
    disabled && styles[`${variant}ButtonDisabled`],
    style,
  ];

  // Get text styles based on variant, size, and state
  const textStyleArray = [
    styles.text,
    styles[`${variant}Text`],
    styles[`${size}Text`],
    disabled && styles[`${variant}TextDisabled`],
    textStyle,
  ];

  // Get icon size based on button size
  const getIconSize = () => {
    switch (size) {
      case 'small':
        return 16;
      case 'large':
        return 24;
      default:
        return 20;
    }
  };

  // Get icon color based on variant and state
  const getIconColor = () => {
    if (disabled) {
      switch (variant) {
        case 'primary':
        case 'secondary':
        case 'danger':
          return theme.colors.white;
        case 'outline':
        case 'ghost':
          return theme.colors.gray[400];
      }
    }

    switch (variant) {
      case 'primary':
      case 'secondary':
      case 'danger':
        return theme.colors.white;
      case 'outline':
        return theme.colors.primary[600];
      case 'ghost':
        return theme.colors.primary[600];
    }
  };

  return (
    <TouchableOpacity
      style={buttonStyle}
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.8}
    >
      {loading ? (
        <ActivityIndicator
          size="small"
          color={variant === 'outline' || variant === 'ghost' ? theme.colors.primary[600] : theme.colors.white}
        />
      ) : (
        <View style={styles.contentContainer}>
          {leftIcon && (
            <Ionicons
              name={leftIcon}
              size={getIconSize()}
              color={getIconColor()}
              style={styles.leftIcon}
            />
          )}
          <Text style={textStyleArray}>{title}</Text>
          {rightIcon && (
            <Ionicons
              name={rightIcon}
              size={getIconSize()}
              color={getIconColor()}
              style={styles.rightIcon}
            />
          )}
        </View>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    borderRadius: theme.borders.radius.m,
    alignItems: 'center',
    justifyContent: 'center',
  },
  fullWidth: {
    width: '100%',
  },
  contentContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    fontWeight: '600',
  },
  leftIcon: {
    marginRight: theme.spacing.s,
  },
  rightIcon: {
    marginLeft: theme.spacing.s,
  },

  // Button variants
  primaryButton: {
    backgroundColor: theme.colors.primary[600],
  },
  secondaryButton: {
    backgroundColor: theme.colors.secondary[600],
  },
  outlineButton: {
    backgroundColor: theme.colors.transparent,
    borderWidth: theme.borders.width.thin,
    borderColor: theme.colors.primary[600],
  },
  ghostButton: {
    backgroundColor: theme.colors.transparent,
  },
  dangerButton: {
    backgroundColor: theme.colors.error.main,
  },

  // Button sizes
  smallButton: {
    paddingVertical: theme.spacing.xs,
    paddingHorizontal: theme.spacing.m,
  },
  mediumButton: {
    paddingVertical: theme.spacing.s,
    paddingHorizontal: theme.spacing.m,
  },
  largeButton: {
    paddingVertical: theme.spacing.m,
    paddingHorizontal: theme.spacing.l,
  },

  // Text variants
  primaryText: {
    color: theme.colors.white,
  },
  secondaryText: {
    color: theme.colors.white,
  },
  outlineText: {
    color: theme.colors.primary[600],
  },
  ghostText: {
    color: theme.colors.primary[600],
  },
  dangerText: {
    color: theme.colors.white,
  },

  // Text sizes
  smallText: {
    fontSize: theme.typography.fontSize.s,
  },
  mediumText: {
    fontSize: theme.typography.fontSize.m,
  },
  largeText: {
    fontSize: theme.typography.fontSize.l,
  },

  // Disabled states
  primaryButtonDisabled: {
    backgroundColor: theme.colors.primary[300],
  },
  secondaryButtonDisabled: {
    backgroundColor: theme.colors.secondary[300],
  },
  outlineButtonDisabled: {
    borderColor: theme.colors.gray[300],
  },
  ghostButtonDisabled: {
    // No specific style for ghost button disabled
  },
  dangerButtonDisabled: {
    backgroundColor: theme.colors.error.light,
  },

  primaryTextDisabled: {
    color: theme.colors.white,
  },
  secondaryTextDisabled: {
    color: theme.colors.white,
  },
  outlineTextDisabled: {
    color: theme.colors.gray[400],
  },
  ghostTextDisabled: {
    color: theme.colors.gray[400],
  },
  dangerTextDisabled: {
    color: theme.colors.white,
  },
});

export default Button;
