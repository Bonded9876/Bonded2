import React, { useEffect, useState } from 'react';
import {
  StyleSheet,
  View,
  Text,
  FlatList,
  TouchableOpacity,
  Alert,
  Modal,
  ScrollView,
  Switch,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { BottomTabNavigationProp } from '@react-navigation/bottom-tabs';
import { CompositeNavigationProp } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { MainTabParamList } from '../../navigation/MainNavigator';
import { MainStackParamList } from '../../navigation/MainNavigator';
import { ROUTES } from '../../constants';
import { useAuth } from '../../hooks/useAuth';
import { useAppDispatch, useAppSelector } from '../../hooks/useRedux';
import {
  fetchDefaultTopics,
  fetchUserTopics,
  fetchCustomTopics,
  joinTopic,
  leaveTopic,
  createCustomTopic,
} from '../../store/slices/topicsSlice';
import { Topic, CustomTopic } from '../../types';
import Button from '../../components/shared/Button';
import Input from '../../components/shared/Input';
import EmptyState from '../../components/shared/EmptyState';
import Header from '../../components/shared/Header';
import theme from '../../theme';

type TopicsScreenNavigationProp = CompositeNavigationProp<
  BottomTabNavigationProp<MainTabParamList, typeof ROUTES.TOPICS>,
  StackNavigationProp<MainStackParamList>
>;

interface TopicsScreenProps {
  navigation: TopicsScreenNavigationProp;
}

const TopicsScreen: React.FC<TopicsScreenProps> = ({ navigation }) => {
  const dispatch = useAppDispatch();
  const { user, hasPaid } = useAuth();
  const { 
    defaultTopics, 
    customTopics, 
    userTopics, 
    isLoading, 
    error 
  } = useAppSelector((state) => state.topics);

  const [activeTab, setActiveTab] = useState<'default' | 'custom'>('default');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newTopicName, setNewTopicName] = useState('');
  const [newTopicDescription, setNewTopicDescription] = useState('');
  const [isPrivate, setIsPrivate] = useState(false);
  const [nameError, setNameError] = useState('');

  // Load topics when component mounts
  useEffect(() => {
    if (user) {
      dispatch(fetchDefaultTopics());
      dispatch(fetchUserTopics(user.id));
      dispatch(fetchCustomTopics(user.id));
    }
  }, [dispatch, user]);

  // Check if payment is required
  const checkPaymentRequired = () => {
    if (!hasPaid) {
      Alert.alert(
        'Payment Required',
        'You need to complete your one-time payment to access this feature.',
        [
          {
            text: 'Pay Now',
            onPress: () => navigation.navigate(ROUTES.PAYMENT),
          },
          {
            text: 'Later',
            style: 'cancel',
          },
        ]
      );
      return true;
    }
    return false;
  };

  // Handle joining a topic
  const handleJoinTopic = async (topicId: string) => {
    if (checkPaymentRequired()) return;

    try {
      if (user) {
        await dispatch(joinTopic({ userId: user.id, topicId })).unwrap();
        Alert.alert('Success', 'You have joined this topic!');
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to join topic. Please try again.');
    }
  };

  // Handle leaving a topic
  const handleLeaveTopic = async (topicId: string) => {
    try {
      if (user) {
        await dispatch(leaveTopic({ userId: user.id, topicId })).unwrap();
        Alert.alert('Success', 'You have left this topic.');
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to leave topic. Please try again.');
    }
  };

  // Handle creating a custom topic
  const handleCreateTopic = async () => {
    if (checkPaymentRequired()) return;

    // Validate form
    if (!newTopicName.trim()) {
      setNameError('Topic name is required');
      return;
    }

    try {
      if (user) {
        const topicData = {
          name: newTopicName.trim(),
          description: newTopicDescription.trim(),
          isPrivate,
          icon: 'people',
          color: theme.colors.primary[600],
          membersCount: 1,
        };

        const result = await dispatch(
          createCustomTopic({ userId: user.id, topicData })
        ).unwrap();

        // Close modal and reset form
        setShowCreateModal(false);
        setNewTopicName('');
        setNewTopicDescription('');
        setIsPrivate(false);
        setNameError('');

        if (result.id) {
          if (isPrivate) {
            const inviteLink = `bonded://join-topic/${result.id}`;
            Alert.alert(
              'Topic Created',
              `Your private topic has been created! Share this link to invite others:\n\n${inviteLink}`,
              [{ text: 'OK' }]
            );
          } else {
            Alert.alert('Success', 'Your topic has been created successfully!');
          }

          // Switch to custom topics tab
          setActiveTab('custom');
        }
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to create topic. Please try again.');
    }
  };

  // Render default topic item
  const renderDefaultTopicItem = ({ item }: { item: Topic }) => {
    const isJoined = userTopics.includes(item.id);

    return (
      <View style={styles.topicCard}>
        <View style={styles.topicInfo}>
          <View
            style={[
              styles.topicIcon,
              { backgroundColor: item.color || theme.colors.primary[600] },
            ]}
          >
            <Ionicons
              name={(item.icon as keyof typeof Ionicons.glyphMap) || 'people'}
              size={20}
              color={theme.colors.white}
            />
          </View>

          <View style={styles.topicContent}>
            <Text style={styles.topicName}>{item.name}</Text>
            <Text style={styles.topicDescription} numberOfLines={2}>
              {item.description}
            </Text>
            <Text style={styles.topicMembers}>
              {item.membersCount} members
            </Text>
          </View>
        </View>

        <Button
          title={isJoined ? 'Leave' : 'Join'}
          variant={isJoined ? 'outline' : 'primary'}
          size="small"
          onPress={() =>
            isJoined ? handleLeaveTopic(item.id) : handleJoinTopic(item.id)
          }
          style={styles.topicButton}
        />
      </View>
    );
  };

  // Render custom topic item
  const renderCustomTopicItem = ({ item }: { item: CustomTopic }) => {
    const isOwner = item.createdBy === user?.id;

    return (
      <TouchableOpacity
        style={styles.customTopicCard}
        onPress={() => navigation.navigate(ROUTES.TOPIC_DETAIL, { topicId: item.id })}
      >
        <View style={styles.customTopicHeader}>
          <View
            style={[
              styles.topicIcon,
              { backgroundColor: item.color || theme.colors.primary[600] },
            ]}
          >
            <Ionicons
              name={(item.icon as keyof typeof Ionicons.glyphMap) || 'people'}
              size={20}
              color={theme.colors.white}
            />
          </View>

          <View style={styles.customTopicContent}>
            <View style={styles.customTopicNameContainer}>
              <Text style={styles.topicName}>{item.name}</Text>
              {item.isPrivate && (
                <Ionicons
                  name="lock-closed"
                  size={16}
                  color={theme.colors.gray[500]}
                  style={styles.privateIcon}
                />
              )}
              {isOwner && (
                <View style={styles.ownerBadge}>
                  <Text style={styles.ownerText}>Owner</Text>
                </View>
              )}
            </View>
            {item.description && (
              <Text style={styles.topicDescription} numberOfLines={2}>
                {item.description}
              </Text>
            )}
            <Text style={styles.topicMembers}>
              {item.membersCount} members
            </Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  // Render empty state for no topics
  const renderEmptyState = () => {
    if (isLoading) {
      return (
        <View style={styles.emptyStateContainer}>
          <ActivityIndicator size="large" color={theme.colors.primary[600]} />
          <Text style={styles.loadingText}>Loading topics...</Text>
        </View>
      );
    }

    if (activeTab === 'default') {
      return (
        <EmptyState
          title="No Default Topics"
          message="There are no default topics available at the moment. Please check back later."
          icon="list"
        />
      );
    }

    return (
      <EmptyState
        title="No Custom Topics"
        message="You haven't created or joined any custom topics yet. Create one by clicking the button below."
        icon="people"
        buttonTitle="Create Topic"
        onButtonPress={() => setShowCreateModal(true)}
      />
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <Header
        title="Topics"
        subtitle="Join topics to connect with like-minded people"
        rightIcon="add-circle"
        onRightPress={() => setShowCreateModal(true)}
      />

      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[
            styles.tab,
            activeTab === 'default' && styles.activeTab,
          ]}
          onPress={() => setActiveTab('default')}
        >
          <Text
            style={[
              styles.tabText,
              activeTab === 'default' && styles.activeTabText,
            ]}
          >
            Default Topics
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.tab,
            activeTab === 'custom' && styles.activeTab,
          ]}
          onPress={() => setActiveTab('custom')}
        >
          <Text
            style={[
              styles.tabText,
              activeTab === 'custom' && styles.activeTabText,
            ]}
          >
            Custom Topics
          </Text>
        </TouchableOpacity>
      </View>

      {activeTab === 'default' ? (
        <FlatList
          data={defaultTopics}
          renderItem={renderDefaultTopicItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContainer}
          ListEmptyComponent={renderEmptyState}
        />
      ) : (
        <View style={styles.customTopicsContainer}>
          <FlatList
            data={customTopics}
            renderItem={renderCustomTopicItem}
            keyExtractor={(item) => item.id}
            contentContainerStyle={styles.listContainer}
            ListEmptyComponent={renderEmptyState}
          />
          {customTopics.length > 0 && (
            <TouchableOpacity
              style={styles.floatingButton}
              onPress={() => setShowCreateModal(true)}
            >
              <Ionicons name="add" size={24} color="#fff" />
            </TouchableOpacity>
          )}
        </View>
      )}

      {/* Create Topic Modal */}
      <Modal
        visible={showCreateModal}
        animationType="slide"
        transparent
        onRequestClose={() => setShowCreateModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Create Topic</Text>
              <TouchableOpacity
                onPress={() => {
                  setShowCreateModal(false);
                  setNewTopicName('');
                  setNewTopicDescription('');
                  setIsPrivate(false);
                  setNameError('');
                }}
              >
                <Ionicons
                  name="close"
                  size={24}
                  color={theme.colors.gray[500]}
                />
              </TouchableOpacity>
            </View>

            <ScrollView>
              <Input
                label="Topic Name"
                placeholder="Enter a name for your topic"
                value={newTopicName}
                onChangeText={(text) => {
                  setNewTopicName(text);
                  if (text.trim()) setNameError('');
                }}
                error={nameError}
                maxLength={50}
              />

              <Input
                label="Description (optional)"
                placeholder="Describe what this topic is about"
                value={newTopicDescription}
                onChangeText={setNewTopicDescription}
                multiline
                numberOfLines={4}
                maxLength={200}
                inputStyle={styles.textArea}
              />

              <View style={styles.switchContainer}>
                <View>
                  <Text style={styles.switchLabel}>Private Topic</Text>
                  <Text style={styles.switchDescription}>
                    {isPrivate
                      ? 'Only people you invite can join this topic'
                      : 'Anyone can discover and join this topic'}
                  </Text>
                </View>
                <Switch
                  value={isPrivate}
                  onValueChange={setIsPrivate}
                  trackColor={{
                    false: theme.colors.gray[300],
                    true: theme.colors.primary[600],
                  }}
                  thumbColor={theme.colors.white}
                />
              </View>

              <Button
                title="Create Topic"
                onPress={handleCreateTopic}
                fullWidth
                style={styles.createButton}
              />
            </ScrollView>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

// Import ActivityIndicator which was referenced but not imported
import { ActivityIndicator } from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.white,
  },
  tabContainer: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.gray[200],
  },
  tab: {
    flex: 1,
    paddingVertical: theme.spacing.m,
    alignItems: 'center',
  },
  activeTab: {
    borderBottomWidth: 2,
    borderBottomColor: theme.colors.primary[600],
  },
  tabText: {
    fontSize: theme.typography.fontSize.m,
    fontWeight: '500',
    color: theme.colors.gray[600],
  },
  activeTabText: {
    color: theme.colors.primary[600],
  },
  listContainer: {
    padding: theme.spacing.m,
    flexGrow: 1,
  },
  topicCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: theme.spacing.m,
    backgroundColor: theme.colors.white,
    borderRadius: theme.borders.radius.m,
    borderWidth: 1,
    borderColor: theme.colors.gray[200],
    marginBottom: theme.spacing.m,
    ...theme.shadows.xs,
  },
  topicInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  topicIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: theme.spacing.m,
  },
  topicContent: {
    flex: 1,
  },
  topicName: {
    fontSize: theme.typography.fontSize.m,
    fontWeight: 'bold',
    color: theme.colors.gray[900],
    marginBottom: theme.spacing.xs,
  },
  topicDescription: {
    fontSize: theme.typography.fontSize.s,
    color: theme.colors.gray[600],
    marginBottom: theme.spacing.xs,
  },
  topicMembers: {
    fontSize: theme.typography.fontSize.xs,
    color: theme.colors.gray[500],
  },
  topicButton: {
    marginLeft: theme.spacing.m,
  },
  customTopicsContainer: {
    flex: 1,
  },
  customTopicCard: {
    padding: theme.spacing.m,
    backgroundColor: theme.colors.white,
    borderRadius: theme.borders.radius.m,
    borderWidth: 1,
    borderColor: theme.colors.gray[200],
    marginBottom: theme.spacing.m,
    ...theme.shadows.xs,
  },
  customTopicHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  customTopicContent: {
    flex: 1,
  },
  customTopicNameContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: theme.spacing.xs,
  },
  privateIcon: {
    marginLeft: theme.spacing.xs,
  },
  ownerBadge: {
    backgroundColor: theme.colors.primary[100],
    paddingHorizontal: theme.spacing.s,
    paddingVertical: theme.spacing.xs,
    borderRadius: theme.borders.radius.s,
    marginLeft: theme.spacing.s,
  },
  ownerText: {
    fontSize: theme.typography.fontSize.xs,
    fontWeight: '500',
    color: theme.colors.primary[700],
  },
  floatingButton: {
    position: 'absolute',
    right: theme.spacing.l,
    bottom: theme.spacing.l,
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: theme.colors.primary[600],
    justifyContent: 'center',
    alignItems: 'center',
    ...theme.shadows.m,
  },
  emptyStateContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: theme.spacing.xl,
  },
  loadingText: {
    marginTop: theme.spacing.m,
    fontSize: theme.typography.fontSize.m,
    color: theme.colors.gray[600],
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContainer: {
    backgroundColor: theme.colors.white,
    borderTopLeftRadius: theme.borders.radius.l,
    borderTopRightRadius: theme.borders.radius.l,
    padding: theme.spacing.l,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing.l,
  },
  modalTitle: {
    fontSize: theme.typography.fontSize.l,
    fontWeight: 'bold',
    color: theme.colors.gray[900],
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  switchContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: theme.spacing.m,
  },
  switchLabel: {
    fontSize: theme.typography.fontSize.m,
    fontWeight: '500',
    color: theme.colors.gray[900],
    marginBottom: theme.spacing.xs,
  },
  switchDescription: {
    fontSize: theme.typography.fontSize.xs,
    color: theme.colors.gray[600],
    maxWidth: '80%',
  },
  createButton: {
    marginTop: theme.spacing.l,
  },
});

export default TopicsScreen;
