import { useEffect, useState } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, firestore } from '../services/firebase';
import { useAppDispatch, useAppSelector } from './useRedux';
import { updateUser } from '../store/slices/authSlice';
import { User } from '../types';

export const useAuth = () => {
  const dispatch = useAppDispatch();
  const { user, isLoading, error } = useAppSelector(state => state.auth);
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        // User is signed in, fetch additional data from Firestore
        try {
          const userDoc = await getDoc(doc(firestore, 'users', firebaseUser.uid));
          
          if (userDoc.exists()) {
            const userData = userDoc.data();
            const user: User = {
              id: firebaseUser.uid,
              email: firebaseUser.email || '',
              displayName: userData.displayName || firebaseUser.displayName || '',
              bio: userData.bio || '',
              profileImage: userData.profileImage || '',
              createdAt: userData.createdAt instanceof Date 
                ? userData.createdAt 
                : new Date(userData.createdAt.seconds * 1000),
              hasPaid: userData.hasPaid || false,
              topics: userData.topics || [],
              location: userData.location ? {
                latitude: userData.location.latitude,
                longitude: userData.location.longitude,
              } : undefined,
              lastLocationUpdate: userData.lastLocationUpdate ? new Date(userData.lastLocationUpdate.seconds * 1000) : undefined,
            };
            
            dispatch(updateUser(user));
          } else {
            // User exists in Auth but not in Firestore
            console.warn('User found in Auth but not in Firestore');
            dispatch(updateUser(null));
          }
        } catch (error) {
          console.error('Error fetching user data:', error);
          dispatch(updateUser(null));
        }
      } else {
        // User is signed out
        dispatch(updateUser(null));
      }
      
      setIsInitialized(true);
    });
    
    return () => unsubscribe();
  }, [dispatch]);

  return {
    user,
    isLoading,
    error,
    isInitialized,
    isAuthenticated: !!user,
    hasPaid: user?.hasPaid || false,
  };
};
