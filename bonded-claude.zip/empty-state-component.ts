import React from 'react';
import {
  StyleSheet,
  View,
  Text,
  StyleProp,
  ViewStyle,
  TextStyle,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Button from './Button';
import theme from '../../theme';

interface EmptyStateProps {
  title: string;
  message?: string;
  icon?: keyof typeof Ionicons.glyphMap;
  buttonTitle?: string;
  onButtonPress?: () => void;
  containerStyle?: StyleProp<ViewStyle>;
  titleStyle?: StyleProp<TextStyle>;
  messageStyle?: StyleProp<TextStyle>;
  iconSize?: number;
  iconColor?: string;
}

const EmptyState: React.FC<EmptyStateProps> = ({
  title,
  message,
  icon = 'alert-circle-outline',
  buttonTitle,
  onButtonPress,
  containerStyle,
  titleStyle,
  messageStyle,
  iconSize = 64,
  iconColor = theme.colors.gray[400],
}) => {
  return (
    <View style={[styles.container, containerStyle]}>
      <Ionicons name={icon} size={iconSize} color={iconColor} />
      <Text style={[styles.title, titleStyle]}>{title}</Text>
      {message && <Text style={[styles.message, messageStyle]}>{message}</Text>}
      {buttonTitle && onButtonPress && (
        <Button
          title={buttonTitle}
          onPress={onButtonPress}
          variant="primary"
          size="medium"
          style={styles.button}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: theme.spacing.xl,
  },
  title: {
    fontSize: theme.typography.fontSize.l,
    fontWeight: 'bold',
    color: theme.colors.gray[800],
    marginTop: theme.spacing.m,
    marginBottom: theme.spacing.xs,
    textAlign: 'center',
  },
  message: {
    fontSize: theme.typography.fontSize.m,
    color: theme.colors.gray[500],
    textAlign: 'center',
    marginBottom: theme.spacing.l,
  },
  button: {
    marginTop: theme.spacing.m,
  },
});

export default EmptyState;
