import React, { useState, useRef } from 'react';
import {
  StyleSheet,
  View,
  Text,
  FlatList,
  Dimensions,
  TouchableOpacity,
  Image,
  ImageBackground,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { StackNavigationProp } from '@react-navigation/stack';
import { SafeAreaView } from 'react-native-safe-area-context';
import { AuthStackParamList } from '../../navigation/AuthNavigator';
import Button from '../../components/shared/Button';
import theme from '../../theme';
import { ROUTES } from '../../constants';

type OnboardingScreenNavigationProp = StackNavigationProp<
  AuthStackParamList,
  typeof ROUTES.ONBOARDING
>;

interface OnboardingScreenProps {
  navigation: OnboardingScreenNavigationProp;
}

const { width } = Dimensions.get('window');

interface OnboardingSlide {
  id: string;
  title: string;
  description: string;
  image: any; // This would be the require() for the local image
  backgroundColor: string[];
}

const slides: OnboardingSlide[] = [
  {
    id: '1',
    title: 'Welcome to Bonded',
    description: 'Connect with real people in real life based on shared interests and topics.',
    image: require('../../assets/images/onboarding-1.png'), // Make sure to create this asset
    backgroundColor: [theme.colors.primary[700], theme.colors.primary[500]],
  },
  {
    id: '2',
    title: 'Find Your Topics',
    description: 'Join topics that interest you and discover people nearby who share your passions.',
    image: require('../../assets/images/onboarding-2.png'), // Make sure to create this asset
    backgroundColor: [theme.colors.secondary[700], theme.colors.secondary[500]],
  },
  {
    id: '3',
    title: 'Connect Safely',
    description: 'Your privacy is important. Control when and to whom you are visible on the map.',
    image: require('../../assets/images/onboarding-3.png'), // Make sure to create this asset
    backgroundColor: [theme.colors.primary[800], theme.colors.primary[600]],
  },
  {
    id: '4',
    title: 'Ready to Start?',
    description: 'Join the Bonded community today to make meaningful connections in your area.',
    image: require('../../assets/images/onboarding-4.png'), // Make sure to create this asset
    backgroundColor: [theme.colors.secondary[800], theme.colors.secondary[600]],
  },
];

const OnboardingScreen: React.FC<OnboardingScreenProps> = ({ navigation }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const flatListRef = useRef<FlatList>(null);

  const renderItem = ({ item }: { item: OnboardingSlide }) => (
    <View style={[styles.slide, { width }]}>
      <LinearGradient
        colors={item.backgroundColor}
        style={styles.background}
      >
        <View style={styles.imageContainer}>
          <Image source={item.image} style={styles.image} />
        </View>
        <View style={styles.textContainer}>
          <Text style={styles.title}>{item.title}</Text>
          <Text style={styles.description}>{item.description}</Text>
        </View>
      </LinearGradient>
    </View>
  );

  const handleNext = () => {
    if (currentIndex < slides.length - 1) {
      flatListRef.current?.scrollToIndex({
        index: currentIndex + 1,
        animated: true,
      });
    } else {
      navigation.navigate(ROUTES.LOGIN);
    }
  };

  const handleSkip = () => {
    navigation.navigate(ROUTES.LOGIN);
  };

  const handleScroll = (event: any) => {
    const { contentOffset } = event.nativeEvent;
    const index = Math.round(contentOffset.x / width);
    if (index !== currentIndex) {
      setCurrentIndex(index);
    }
  };

  const isLastSlide = currentIndex === slides.length - 1;

  return (
    <View style={styles.container}>
      <FlatList
        ref={flatListRef}
        data={slides}
        renderItem={renderItem}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={handleScroll}
        scrollEventThrottle={16}
        keyExtractor={(item) => item.id}
      />

      <SafeAreaView edges={['bottom']} style={styles.footer}>
        <View style={styles.pagination}>
          {slides.map((_, index) => (
            <View
              key={index}
              style={[
                styles.paginationDot,
                index === currentIndex && styles.paginationDotActive,
              ]}
            />
          ))}
        </View>

        <View style={styles.buttonsContainer}>
          {!isLastSlide && (
            <TouchableOpacity onPress={handleSkip} style={styles.skipButton}>
              <Text style={styles.skipButtonText}>Skip</Text>
            </TouchableOpacity>
          )}

          <Button
            title={isLastSlide ? "Let's Get Started" : 'Next'}
            onPress={handleNext}
            fullWidth={isLastSlide}
            rightIcon={!isLastSlide ? 'arrow-forward' : undefined}
          />
        </View>
      </SafeAreaView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.white,
  },
  slide: {
    flex: 1,
  },
  background: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: theme.spacing.l,
  },
  imageContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
  },
  image: {
    width: width * 0.7,
    height: width * 0.7,
    resizeMode: 'contain',
  },
  textContainer: {
    alignItems: 'center',
    marginBottom: theme.spacing.xxxl,
  },
  title: {
    fontSize: theme.typography.fontSize.xxl,
    fontWeight: 'bold',
    color: theme.colors.white,
    marginBottom: theme.spacing.m,
    textAlign: 'center',
  },
  description: {
    fontSize: theme.typography.fontSize.m,
    color: theme.colors.white,
    textAlign: 'center',
    paddingHorizontal: theme.spacing.m,
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'transparent',
    padding: theme.spacing.l,
  },
  pagination: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: theme.spacing.m,
  },
  paginationDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: 'rgba(255, 255, 255, 0.4)',
    marginHorizontal: 4,
  },
  paginationDotActive: {
    backgroundColor: theme.colors.white,
    width: 20,
  },
  buttonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  skipButton: {
    padding: theme.spacing.m,
  },
  skipButtonText: {
    color: theme.colors.white,
    fontSize: theme.typography.fontSize.m,
    fontWeight: '500',
  },
});

export default OnboardingScreen;
