import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  View,
  Text,
  FlatList,
  TouchableOpacity,
  Modal,
  ScrollView,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { format, addDays, isPast } from 'date-fns';
import DateTimePicker from '@react-native-community/datetimepicker';
import { BottomTabNavigationProp } from '@react-navigation/bottom-tabs';
import { CompositeNavigationProp } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { MainTabParamList } from '../../navigation/MainNavigator';
import { MainStackParamList } from '../../navigation/MainNavigator';
import { ROUTES } from '../../constants';
import { useAuth } from '../../hooks/useAuth';
import { useAppDispatch, useAppSelector } from '../../hooks/useRedux';
import Header from '../../components/shared/Header';
import Button from '../../components/shared/Button';
import Input from '../../components/shared/Input';
import Avatar from '../../components/shared/Avatar';
import EmptyState from '../../components/shared/EmptyState';
import theme from '../../theme';
import { Meetup } from '../../types';

type MeetupsScreenNavigationProp = CompositeNavigationProp<
  BottomTabNavigationProp<MainTabParamList, typeof ROUTES.MEETUPS>,
  StackNavigationProp<MainStackParamList>
>;

interface MeetupsScreenProps {
  navigation: MeetupsScreenNavigationProp;
}

const MeetupsScreen: React.FC<MeetupsScreenProps> = ({ navigation }) => {
  const { user, hasPaid } = useAuth();
  const { userTopics, defaultTopics } = useAppSelector((state) => state.topics);
  
  const [meetups, setMeetups] = useState<Meetup[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedMeetup, setSelectedMeetup] = useState<Meetup | null>(null);
  const [showMeetupModal, setShowMeetupModal] = useState(false);
  const [showDatePicker, setShowDatePicker] = useState(false);
  
  // Form state for creating a meetup
  const [meetupTitle, setMeetupTitle] = useState('');
  const [meetupDescription, setMeetupDescription] = useState('');
  const [meetupLocation, setMeetupLocation] = useState('');
  const [meetupDate, setMeetupDate] = useState(addDays(new Date(), 1));
  const [meetupTopic, setMeetupTopic] = useState('');
  const [titleError, setTitleError] = useState('');
  const [locationError, setLocationError] = useState('');

  // Fetch meetups when component mounts
  useEffect(() => {
    const fetchMeetups = async () => {
      // In a real app, this would be an API call to fetch meetups
      // For this prototype, we'll use mock data
      try {
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Mock meetups data
        const mockMeetups: Meetup[] = [
          {
            id: '1',
            title: 'Creative Minds Coffee Meetup',
            description: 'Let\'s gather at the local coffee shop to discuss creative projects and ideas. All creative disciplines welcome!',
            location: 'Starbucks on Main Street',
            date: addDays(new Date(), 2),
            organizer: 'user123',
            topic: 'creative',
            attendees: ['user123', 'user456', 'user789'],
          },
          {
            id: '2',
            title: 'Weekend Trail Run',
            description: 'A casual trail run for all fitness levels. We\'ll meet at the park entrance and run together for about 5km.',
            location: 'Emerald Park Entrance',
            date: addDays(new Date(), 4),
            organizer: 'user456',
            topic: 'active',
            attendees: ['user456', 'user789'],
          },
          {
            id: '3',
            title: 'Book Club Discussion: Sci-Fi Classics',
            description: 'Monthly book club meeting to discuss classic science fiction novels. This month we\'re reading "Dune" by Frank Herbert.',
            location: 'City Library, Room 3B',
            date: addDays(new Date(), 7),
            organizer: 'user789',
            topic: 'knowledge',
            attendees: ['user123', 'user789'],
          },
        ];
        
        setMeetups(mockMeetups);
      } catch (error) {
        console.error('Error fetching meetups:', error);
        Alert.alert('Error', 'Failed to load meetups');
      } finally {
        setLoading(false);
      }
    };
    
    fetchMeetups();
  }, []);

  // Filter user's topics
  const userTopicDetails = defaultTopics.filter((topic) => 
    userTopics.includes(topic.id)
  );

  // Handle creating a meetup
  const handleCreateMeetup = () => {
    // Validate form
    let isValid = true;
    
    if (!meetupTitle.trim()) {
      setTitleError('Title is required');
      isValid = false;
    }
    
    if (!meetupLocation.trim()) {
      setLocationError('Location is required');
      isValid = false;
    }
    
    if (!isValid) return;
    
    // Create new meetup object
    const newMeetup: Meetup = {
      id: `meetup_${Date.now()}`,
      title: meetupTitle.trim(),
      description: meetupDescription.trim(),
      location: meetupLocation.trim(),
      date: meetupDate,
      organizer: user?.id || 'unknown',
      topic: meetupTopic || (userTopics.length > 0 ? userTopics[0] : ''),
      attendees: [user?.id || 'unknown'],
    };
    
    // Add to meetups list
    setMeetups((prev) => [newMeetup, ...prev]);
    
    // Close modal and reset form
    setShowCreateModal(false);
    resetForm();
    
    // Show confirmation
    Alert.alert('Success', 'Meetup created successfully!');
  };

  // Handle joining a meetup
  const handleJoinMeetup = (meetup: Meetup) => {
    if (!user) return;
    
    // Check if already joined
    const isJoined = meetup.attendees.includes(user.id);
    
    if (isJoined) {
      // Leave meetup
      const updatedMeetups = meetups.map((m) => {
        if (m.id === meetup.id) {
          return {
            ...m,
            attendees: m.attendees.filter((id) => id !== user.id),
          };
        }
        return m;
      });
      
      setMeetups(updatedMeetups);
      
      if (selectedMeetup?.id === meetup.id) {
        setSelectedMeetup({
          ...selectedMeetup,
          attendees: selectedMeetup.attendees.filter((id) => id !== user.id),
        });
      }
      
      Alert.alert('Success', 'You have left this meetup');
    } else {
      // Join meetup
      const updatedMeetups = meetups.map((m) => {
        if (m.id === meetup.id) {
          return {
            ...m,
            attendees: [...m.attendees, user.id],
          };
        }
        return m;
      });
      
      setMeetups(updatedMeetups);
      
      if (selectedMeetup?.id === meetup.id) {
        setSelectedMeetup({
          ...selectedMeetup,
          attendees: [...selectedMeetup.attendees, user.id],
        });
      }
      
      Alert.alert('Success', 'You have joined this meetup');
    }
  };

  // Reset form state
  const resetForm = () => {
    setMeetupTitle('');
    setMeetupDescription('');
    setMeetupLocation('');
    setMeetupDate(addDays(new Date(), 1));
    setMeetupTopic('');
    setTitleError('');
    setLocationError('');
  };

  // Get topic name from ID
  const getTopicName = (topicId: string) => {
    const topic = defaultTopics.find((t) => t.id === topicId);
    return topic ? topic.name : 'General';
  };

  // Get topic color from ID
  const getTopicColor = (topicId: string) => {
    const topic = defaultTopics.find((t) => t.id === topicId);
    return topic ? topic.color : theme.colors.primary[600];
  };

  // Check if user has joined a meetup
  const hasJoinedMeetup = (meetup: Meetup) => {
    return user ? meetup.attendees.includes(user.id) : false;
  };

  // Filter meetups by status (upcoming or past)
  const upcomingMeetups = meetups.filter((meetup) => !isPast(meetup.date));
  const pastMeetups = meetups.filter((meetup) => isPast(meetup.date));

  // Render meetup item
  const renderMeetupItem = ({ item }: { item: Meetup }) => {
    const isJoined = hasJoinedMeetup(item);
    const isPastEvent = isPast(item.date);
    
    return (
      <TouchableOpacity
        style={styles.meetupCard}
        onPress={() => {
          setSelectedMeetup(item);
          setShowMeetupModal(true);
        }}
      >
        <View style={styles.meetupHeader}>
          <View
            style={[
              styles.meetupTopic,
              { backgroundColor: getTopicColor(item.topic) + '20' }, // Add transparency
            ]}
          >
            <Text
              style={[
                styles.meetupTopicText,
                { color: getTopicColor(item.topic) },
              ]}
            >
              {getTopicName(item.topic)}
            </Text>
          </View>
          
          {isPastEvent && (
            <View style={styles.pastBadge}>
              <Text style={styles.pastBadgeText}>Past</Text>
            </View>
          )}
        </View>
        
        <Text style={styles.meetupTitle}>{item.title}</Text>
        
        <View style={styles.meetupDetails}>
          <View style={styles.meetupDetail}>
            <Ionicons name="calendar" size={16} color={theme.colors.gray[600]} />
            <Text style={styles.meetupDetailText}>
              {format(item.date, 'EEEE, MMM d, yyyy • h:mm a')}
            </Text>
          </View>
          
          <View style={styles.meetupDetail}>
            <Ionicons name="location" size={16} color={theme.colors.gray[600]} />
            <Text style={styles.meetupDetailText}>{item.location}</Text>
          </View>
        </View>
        
        <View style={styles.meetupFooter}>
          <View style={styles.attendeesContainer}>
            {/* Attendee avatars */}
            <View style={styles.avatarRow}>
              {item.attendees.slice(0, 3).map((attendeeId, index) => (
                <View
                  key={attendeeId}
                  style={[
                    styles.attendeeAvatar,
                    { zIndex: 3 - index, marginLeft: index > 0 ? -10 : 0 },
                  ]}
                >
                  <Avatar
                    initials={attendeeId.charAt(0).toUpperCase()}
                    size="xs"
                  />
                </View>
              ))}
              
              {item.attendees.length > 3 && (
                <View style={styles.extraAttendees}>
                  <Text style={styles.extraAttendeesText}>
                    +{item.attendees.length - 3}
                  </Text>
                </View>
              )}
            </View>
            
            <Text style={styles.attendeesText}>
              {item.attendees.length} {item.attendees.length === 1 ? 'person' : 'people'} going
            </Text>
          </View>
          
          {!isPastEvent && (
            <Button
              title={isJoined ? 'Leave' : 'Join'}
              variant={isJoined ? 'outline' : 'primary'}
              size="small"
              onPress={() => handleJoinMeetup(item)}
            />
          )}
        </View>
      </TouchableOpacity>
    );
  };

  // If payment required
  if (!hasPaid) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <Header title="Meetups" />
        <EmptyState
          title="Payment Required"
          message="Complete your one-time payment to access meetup features."
          icon="lock-closed"
          buttonTitle="Pay Now"
          onButtonPress={() => navigation.navigate(ROUTES.PAYMENT)}
        />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <Header
        title="Meetups"
        rightIcon="add-circle"
        onRightPress={() => setShowCreateModal(true)}
      />
      
      <View style={styles.content}>
        {/* Tabs for Upcoming and Past meetups */}
        <View style={styles.tabContainer}>
          <TouchableOpacity
            style={[styles.tab, styles.activeTab]}
            // In a more complex app, this would toggle between tabs
          >
            <Text style={[styles.tabText, styles.activeTabText]}>
              Upcoming Meetups
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={styles.tab}
            // In a more complex app, this would toggle between tabs
          >
            <Text style={styles.tabText}>Past Meetups</Text>
          </TouchableOpacity>
        </View>
        
        {/* Meetups list */}
        <FlatList
          data={upcomingMeetups}
          renderItem={renderMeetupItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContainer}
          ListEmptyComponent={
            <EmptyState
              title="No Upcoming Meetups"
              message="There are no upcoming meetups scheduled. Create one to get started!"
              icon="calendar"
              buttonTitle="Create Meetup"
              onButtonPress={() => setShowCreateModal(true)}
            />
          }
        />
      </View>
      
      {/* Create Meetup Modal */}
      <Modal
        visible={showCreateModal}
        animationType="slide"
        transparent
        onRequestClose={() => {
          setShowCreateModal(false);
          resetForm();
        }}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Create Meetup</Text>
              <TouchableOpacity
                onPress={() => {
                  setShowCreateModal(false);
                  resetForm();
                }}
              >
                <Ionicons name="close" size={24} color={theme.colors.gray[500]} />
              </TouchableOpacity>
            </View>
            
            <ScrollView showsVerticalScrollIndicator={false}>
              <Input
                label="Title"
                placeholder="Enter meetup title"
                value={meetupTitle}
                onChangeText={(text) => {
                  setMeetupTitle(text);
                  if (text.trim()) setTitleError('');
                }}
                error={titleError}
                maxLength={100}
              />
              
              <Input
                label="Description (optional)"
                placeholder="Describe what this meetup is about"
                value={meetupDescription}
                onChangeText={setMeetupDescription}
                multiline
                numberOfLines={4}
                maxLength={500}
                inputStyle={styles.textArea}
              />
              
              <Input
                label="Location"
                placeholder="Enter meetup location"
                value={meetupLocation}
                onChangeText={(text) => {
                  setMeetupLocation(text);
                  if (text.trim()) setLocationError('');
                }}
                error={locationError}
                maxLength={100}
                leftIcon="location"
              />
              
              <Text style={styles.inputLabel}>Date and Time</Text>
              <TouchableOpacity
                style={styles.datePickerButton}
                onPress={() => setShowDatePicker(true)}
              >
                <Ionicons name="calendar" size={20} color={theme.colors.gray[600]} />
                <Text style={styles.datePickerText}>
                  {format(meetupDate, 'EEEE, MMM d, yyyy • h:mm a')}
                </Text>
              </TouchableOpacity>
              
              {showDatePicker && (
                <DateTimePicker
                  value={meetupDate}
                  mode="datetime"
                  display="default"
                  minimumDate={new Date()}
                  onChange={(event, selectedDate) => {
                    setShowDatePicker(false);
                    if (selectedDate) {
                      setMeetupDate(selectedDate);
                    }
                  }}
                />
              )}
              
              <Text style={styles.inputLabel}>Topic</Text>
              <View style={styles.topicSelector}>
                {userTopicDetails.length === 0 ? (
                  <Text style={styles.noTopicsText}>
                    You haven't joined any topics yet. Go to the Topics tab to join topics.
                  </Text>
                ) : (
                  userTopicDetails.map((topic) => (
                    <TouchableOpacity
                      key={topic.id}
                      style={[
                        styles.topicOption,
                        meetupTopic === topic.id && {
                          backgroundColor: topic.color + '20',
                          borderColor: topic.color,
                        },
                      ]}
                      onPress={() => setMeetupTopic(topic.id)}
                    >
                      <Text
                        style={[
                          styles.topicOptionText,
                          meetupTopic === topic.id && { color: topic.color },
                        ]}
                      >
                        {topic.name}
                      </Text>
                      {meetupTopic === topic.id && (
                        <Ionicons
                          name="checkmark-circle"
                          size={20}
                          color={topic.color}
                        />
                      )}
                    </TouchableOpacity>
                  ))
                )}
              </View>
              
              <Button
                title="Create Meetup"
                onPress={handleCreateMeetup}
                fullWidth
                style={styles.createButton}
                disabled={userTopicDetails.length === 0}
              />
            </ScrollView>
          </View>
        </View>
      </Modal>
      
      {/* Meetup Detail Modal */}
      <Modal
        visible={showMeetupModal}
        animationType="slide"
        transparent
        onRequestClose={() => {
          setShowMeetupModal(false);
          setSelectedMeetup(null);
        }}
      >
        {selectedMeetup && (
          <View style={styles.modalOverlay}>
            <View style={styles.modalContainer}>
              <View style={styles.modalHeader}>
                <Text style={styles.modalTitle}>Meetup Details</Text>
                <TouchableOpacity
                  onPress={() => {
                    setShowMeetupModal(false);
                    setSelectedMeetup(null);
                  }}
                >
                  <Ionicons name="close" size={24} color={theme.colors.gray[500]} />
                </TouchableOpacity>
              </View>
              
              <ScrollView showsVerticalScrollIndicator={false}>
                <View
                  style={[
                    styles.meetupTopic,
                    { backgroundColor: getTopicColor(selectedMeetup.topic) + '20' },
                  ]}
                >
                  <Text
                    style={[
                      styles.meetupTopicText,
                      { color: getTopicColor(selectedMeetup.topic) },
                    ]}
                  >
                    {getTopicName(selectedMeetup.topic)}
                  </Text>
                </View>
                
                <Text style={styles.detailTitle}>{selectedMeetup.title}</Text>
                
                <View style={styles.detailSection}>
                  <View style={styles.meetupDetail}>
                    <Ionicons name="calendar" size={20} color={theme.colors.gray[600]} />
                    <Text style={styles.meetupDetailText}>
                      {format(selectedMeetup.date, 'EEEE, MMM d, yyyy • h:mm a')}
                    </Text>
                  </View>
                  
                  <View style={styles.meetupDetail}>
                    <Ionicons name="location" size={20} color={theme.colors.gray[600]} />
                    <Text style={styles.meetupDetailText}>{selectedMeetup.location}</Text>
                  </View>
                  
                  <View style={styles.meetupDetail}>
                    <Ionicons name="person" size={20} color={theme.colors.gray[600]} />
                    <Text style={styles.meetupDetailText}>
                      Organized by {selectedMeetup.organizer === user?.id ? 'you' : 'User ' + selectedMeetup.organizer.substring(0, 5)}
                    </Text>
                  </View>
                </View>
                
                {selectedMeetup.description && (
                  <View style={styles.detailSection}>
                    <Text style={styles.sectionTitle}>Description</Text>
                    <Text style={styles.descriptionText}>
                      {selectedMeetup.description}
                    </Text>
                  </View>
                )}
                
                <View style={styles.detailSection}>
                  <Text style={styles.sectionTitle}>
                    Attendees ({selectedMeetup.attendees.length})
                  </Text>
                  <View style={styles.attendeesList}>
                    {selectedMeetup.attendees.map((attendeeId) => (
                      <View key={attendeeId} style={styles.attendeeItem}>
                        <Avatar
                          initials={attendeeId.charAt(0).toUpperCase()}
                          size="s"
                        />
                        <Text style={styles.attendeeName}>
                          {attendeeId === user?.id ? 'You' : 'User ' + attendeeId.substring(0, 5)}
                        </Text>
                      </View>
                    ))}
                  </View>
                </View>
                
                {!isPast(selectedMeetup.date) && (
                  <Button
                    title={hasJoinedMeetup(selectedMeetup) ? 'Leave Meetup' : 'Join Meetup'}
                    variant={hasJoinedMeetup(selectedMeetup) ? 'outline' : 'primary'}
                    onPress={() => handleJoinMeetup(selectedMeetup)}
                    fullWidth
                    style={styles.actionButton}
                  />
                )}
              </ScrollView>
            </View>
          </View>
        )}
      </Modal>
      
      {/* Floating action button */}
      <TouchableOpacity
        style={styles.fab}
        onPress={() => setShowCreateModal(true)}
      >
        <Ionicons name="add" size={24} color={theme.colors.white} />
      </TouchableOpacity>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.white,
  },
  content: {
    flex: 1,
  },
  tabContainer: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.gray[200],
  },
  tab: {
    flex: 1,
    paddingVertical: theme.spacing.m,
    alignItems: 'center',
  },
  activeTab: {
    borderBottomWidth: 2,
    borderBottomColor: theme.colors.primary[600],
  },
  tabText: {
    fontSize: theme.typography.fontSize.m,
    fontWeight: '500',
    color: theme.colors.gray[600],
  },
  activeTabText: {
    color: theme.colors.primary[600],
  },
  listContainer: {
    padding: theme.spacing.m,
    flexGrow: 1,
  },
  meetupCard: {
    backgroundColor: theme.colors.white,
    borderRadius: theme.borders.radius.m,
    padding: theme.spacing.m,
    marginBottom: theme.spacing.m,
    borderWidth: 1,
    borderColor: theme.colors.gray[200],
    ...theme.shadows.xs,
  },
  meetupHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: theme.spacing.s,
  },
  meetupTopic: {
    paddingHorizontal: theme.spacing.m,
    paddingVertical: theme.spacing.xs,
    borderRadius: theme.borders.radius.l,
    alignSelf: 'flex-start',
  },
  meetupTopicText: {
    fontSize: theme.typography.fontSize.xs,
    fontWeight: '500',
  },
  pastBadge: {
    backgroundColor: theme.colors.gray[200],
    paddingHorizontal: theme.spacing.m,
    paddingVertical: theme.spacing.xs,
    borderRadius: theme.borders.radius.l,
  },
  pastBadgeText: {
    fontSize: theme.typography.fontSize.xs,
    fontWeight: '500',
    color: theme.colors.gray[600],
  },
  meetupTitle: {
    fontSize: theme.typography.fontSize.l,
    fontWeight: 'bold',
    color: theme.colors.gray[900],
    marginBottom: theme.spacing.m,
  },
  meetupDetails: {
    marginBottom: theme.spacing.m,
  },
  meetupDetail: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: theme.spacing.s,
  },
  meetupDetailText: {
    fontSize: theme.typography.fontSize.s,
    color: theme.colors.gray[800],
    marginLeft: theme.spacing.s,
  },
  meetupFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  attendeesContainer: {
    flex: 1,
  },
  avatarRow: {
    flexDirection: 'row',
    marginBottom: theme.spacing.xs,
  },
  attendeeAvatar: {
    marginRight: -10,
  },
  extraAttendees: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: theme.colors.gray[300],
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: -10,
  },
  extraAttendeesText: {
    fontSize: theme.typography.fontSize.xs,
    color: theme.colors.gray[800],
    fontWeight: '500',
  },
  attendeesText: {
    fontSize: theme.typography.fontSize.xs,
    color: theme.colors.gray[600],
  },
  fab: {
    position: 'absolute',
    right: theme.spacing.l,
    bottom: theme.spacing.l,
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: theme.colors.primary[600],
    justifyContent: 'center',
    alignItems: 'center',
    ...theme.shadows.m,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContainer: {
    backgroundColor: theme.colors.white,
    borderTopLeftRadius: theme.borders.radius.l,
    borderTopRightRadius: theme.borders.radius.l,
    padding: theme.spacing.l,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing.l,
  },
  modalTitle: {
    fontSize: theme.typography.fontSize.l,
    fontWeight: 'bold',
    color: theme.colors.gray[900],
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  inputLabel: {
    fontSize: theme.typography.fontSize.s,
    fontWeight: '500',
    color: theme.colors.gray[700],
    marginBottom: theme.spacing.xs,
  },
  datePickerButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: theme.spacing.m,
    borderWidth: 1,
    borderColor: theme.colors.gray[300],
    borderRadius: theme.borders.radius.m,
    marginBottom: theme.spacing.m,
  },
  datePickerText: {
    fontSize: theme.typography.fontSize.m,
    color: theme.colors.gray[900],
    marginLeft: theme.spacing.s,
  },
  topicSelector: {
    marginBottom: theme.spacing.m,
  },
  topicOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: theme.spacing.m,
    borderWidth: 1,
    borderColor: theme.colors.gray[300],
    borderRadius: theme.borders.radius.m,
    marginBottom: theme.spacing.s,
  },
  topicOptionText: {
    fontSize: theme.typography.fontSize.m,
    color: theme.colors.gray[900],
  },
  noTopicsText: {
    fontSize: theme.typography.fontSize.m,
    color: theme.colors.gray[600],
    fontStyle: 'italic',
    textAlign: 'center',
    padding: theme.spacing.m,
  },
  createButton: {
    marginTop: theme.spacing.m,
    marginBottom: theme.spacing.l,
  },
  detailTitle: {
    fontSize: theme.typography.fontSize.xl,
    fontWeight: 'bold',
    color: theme.colors.gray[900],
    marginTop: theme.spacing.m,
    marginBottom: theme.spacing.m,
  },
  detailSection: {
    marginBottom: theme.spacing.l,
  },
  sectionTitle: {
    fontSize: theme.typography.fontSize.m,
    fontWeight: 'bold',
    color: theme.colors.gray[900],
    marginBottom: theme.spacing.m,
  },
  descriptionText: {
    fontSize: theme.typography.fontSize.m,
    color: theme.colors.gray[800],
    lineHeight: 22,
  },
  attendeesList: {
    marginTop: theme.spacing.s,
  },
  attendeeItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: theme.spacing.m,
  },
  attendeeName: {
    fontSize: theme.typography.fontSize.m,
    color: theme.colors.gray[900],
    marginLeft: theme.spacing.m,
  },
  actionButton: {
    marginTop: theme.spacing.m,
    marginBottom: theme.spacing.l,
  },
});

export default MeetupsScreen;
