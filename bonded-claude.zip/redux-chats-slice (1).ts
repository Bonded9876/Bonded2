import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc,
  updateDoc,
  addDoc,
  query,
  where,
  orderBy,
  limit,
  Timestamp,
  serverTimestamp,
  writeBatch,
  onSnapshot,
} from 'firebase/firestore';
import { firestore } from '../../services/firebase';
import { Chat, Message } from '../../types';
import { DEFAULT_CHAT_LOAD_LIMIT } from '../../constants';

interface ChatsState {
  chats: Chat[];
  currentChat: Chat | null;
  messages: Record<string, Message[]>;
  isLoading: boolean;
  error: string | null;
}

// Initial state
const initialState: ChatsState = {
  chats: [],
  currentChat: null,
  messages: {},
  isLoading: false,
  error: null,
};

// Fetch user chats
export const fetchUserChats = createAsyncThunk(
  'chats/fetchUserChats',
  async (userId: string, { rejectWithValue }) => {
    try {
      const chatsRef = collection(firestore, 'chats');
      const q = query(
        chatsRef,
        where('participants', 'array-contains', userId),
        orderBy('lastMessageTimestamp', 'desc')
      );
      
      const snapshot = await getDocs(q);
      
      const chats: Chat[] = [];
      snapshot.forEach((doc) => {
        const chatData = doc.data();
        chats.push({
          id: doc.id,
          participants: chatData.participants,
          createdAt: chatData.createdAt instanceof Timestamp 
            ? chatData.createdAt.toDate() 
            : new Date(chatData.createdAt.seconds * 1000),
          lastMessage: chatData.lastMessage,
          lastMessageTimestamp: chatData.lastMessageTimestamp instanceof Timestamp 
            ? chatData.lastMessageTimestamp.toDate() 
            : chatData.lastMessageTimestamp 
              ? new Date(chatData.lastMessageTimestamp.seconds * 1000) 
              : undefined,
        });
      });
      
      return chats;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Create or get existing chat
export const createOrGetChat = createAsyncThunk(
  'chats/createOrGetChat',
  async ({ currentUserId, otherUserId }: { currentUserId: string; otherUserId: string }, { rejectWithValue }) => {
    try {
      // Check if a chat already exists
      const chatsRef = collection(firestore, 'chats');
      const q = query(
        chatsRef,
        where('participants', 'array-contains', currentUserId)
      );
      
      const snapshot = await getDocs(q);
      let existingChat: Chat | null = null;
      
      snapshot.forEach((doc) => {
        const chatData = doc.data();
        if (chatData.participants.includes(otherUserId)) {
          existingChat = {
            id: doc.id,
            participants: chatData.participants,
            createdAt: chatData.createdAt instanceof Timestamp 
              ? chatData.createdAt.toDate() 
              : new Date(chatData.createdAt.seconds * 1000),
            lastMessage: chatData.lastMessage,
            lastMessageTimestamp: chatData.lastMessageTimestamp instanceof Timestamp 
              ? chatData.lastMessageTimestamp.toDate() 
              : chatData.lastMessageTimestamp 
                ? new Date(chatData.lastMessageTimestamp.seconds * 1000) 
                : undefined,
          };
        }
      });
      
      if (existingChat) {
        return existingChat;
      }
      
      // Create a new chat
      const newChat = {
        participants: [currentUserId, otherUserId],
        createdAt: new Date(),
      };
      
      const chatRef = await addDoc(chatsRef, {
        ...newChat,
        createdAt: serverTimestamp(),
      });
      
      return {
        id: chatRef.id,
        ...newChat,
      } as Chat;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Send a message
export const sendMessage = createAsyncThunk(
  'chats/sendMessage',
  async ({ 
    chatId, 
    senderId, 
    text 
  }: { 
    chatId: string; 
    senderId: string; 
    text: string 
  }, { rejectWithValue }) => {
    try {
      // Add message to the messages collection
      const messagesRef = collection(firestore, 'messages');
      const timestamp = new Date();
      
      const newMessage = {
        chatId,
        senderId,
        text,
        timestamp,
        read: false,
      };
      
      const messageRef = await addDoc(messagesRef, {
        ...newMessage,
        timestamp: serverTimestamp(),
      });
      
      // Update the chat's last message
      const chatRef = doc(firestore, 'chats', chatId);
      await updateDoc(chatRef, {
        lastMessage: text,
        lastMessageTimestamp: serverTimestamp(),
      });
      
      return {
        id: messageRef.id,
        ...newMessage,
      } as Message;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Fetch messages for a chat
export const fetchMessages = createAsyncThunk(
  'chats/fetchMessages',
  async ({ 
    chatId, 
    messageLimit = DEFAULT_CHAT_LOAD_LIMIT 
  }: { 
    chatId: string; 
    messageLimit?: number 
  }, { rejectWithValue }) => {
    try {
      const messagesRef = collection(firestore, 'messages');
      const q = query(
        messagesRef,
        where('chatId', '==', chatId),
        orderBy('timestamp', 'desc'),
        limit(messageLimit)
      );
      
      const snapshot = await getDocs(q);
      
      const messages: Message[] = [];
      snapshot.forEach((doc) => {
        const messageData = doc.data();
        messages.push({
          id: doc.id,
          chatId: messageData.chatId,
          senderId: messageData.senderId,
          text: messageData.text,
          timestamp: messageData.timestamp instanceof Timestamp 
            ? messageData.timestamp.toDate() 
            : new Date(messageData.timestamp.seconds * 1000),
          read: messageData.read,
        });
      });
      
      // Sort messages by timestamp (oldest first)
      return {
        chatId,
        messages: messages.reverse(),
      };
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Mark messages as read
export const markMessagesAsRead = createAsyncThunk(
  'chats/markAsRead',
  async ({ 
    chatId, 
    userId 
  }: { 
    chatId: string; 
    userId: string 
  }, { rejectWithValue }) => {
    try {
      const messagesRef = collection(firestore, 'messages');
      const q = query(
        messagesRef,
        where('chatId', '==', chatId),
        where('senderId', '!=', userId),
        where('read', '==', false)
      );
      
      const snapshot = await getDocs(q);
      
      if (snapshot.empty) {
        return { chatId, messagesUpdated: 0 };
      }
      
      const batch = writeBatch(firestore);
      
      snapshot.forEach((document) => {
        batch.update(doc(firestore, 'messages', document.id), { read: true });
      });
      
      await batch.commit();
      
      return { 
        chatId, 
        messagesUpdated: snapshot.size 
      };
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Chats slice
const chatsSlice = createSlice({
  name: 'chats',
  initialState,
  reducers: {
    setCurrentChat: (state, action: PayloadAction<Chat | null>) => {
      state.currentChat = action.payload;
    },
    addMessage: (state, action: PayloadAction<{ chatId: string; message: Message }>) => {
      const { chatId, message } = action.payload;
      
      if (!state.messages[chatId]) {
        state.messages[chatId] = [];
      }
      
      state.messages[chatId].push(message);
      
      // Update chat's last message
      const chatIndex = state.chats.findIndex(chat => chat.id === chatId);
      if (chatIndex !== -1) {
        state.chats[chatIndex].lastMessage = message.text;
        state.chats[chatIndex].lastMessageTimestamp = message.timestamp;
        
        // Move this chat to the top of the list
        const chat = state.chats[chatIndex];
        state.chats.splice(chatIndex, 1);
        state.chats.unshift(chat);
      }
    },
    clearChatsError: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    // Fetch user chats
    builder.addCase(fetchUserChats.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(fetchUserChats.fulfilled, (state, action) => {
      state.isLoading = false;
      state.chats = action.payload;
    });
    builder.addCase(fetchUserChats.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });
    
    // Create or get chat
    builder.addCase(createOrGetChat.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(createOrGetChat.fulfilled, (state, action) => {
      state.isLoading = false;
      state.currentChat = action.payload;
      
      // Add to chats list if it's not already there
      const chatExists = state.chats.some(chat => chat.id === action.payload.id);
      if (!chatExists) {
        state.chats.unshift(action.payload);
      }
    });
    builder.addCase(createOrGetChat.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });
    
    // Send message
    builder.addCase(sendMessage.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(sendMessage.fulfilled, (state, action) => {
      state.isLoading = false;
      
      const chatId = action.payload.chatId;
      
      if (!state.messages[chatId]) {
        state.messages[chatId] = [];
      }
      
      state.messages[chatId].push(action.payload);
      
      // Update chat's last message
      const chatIndex = state.chats.findIndex(chat => chat.id === chatId);
      if (chatIndex !== -1) {
        state.chats[chatIndex].lastMessage = action.payload.text;
        state.chats[chatIndex].lastMessageTimestamp = action.payload.timestamp;
        
        // Move this chat to the top of the list
        const chat = state.chats[chatIndex];
        state.chats.splice(chatIndex, 1);
        state.chats.unshift(chat);
      }
    });
    builder.addCase(sendMessage.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });
    
    // Fetch messages
    builder.addCase(fetchMessages.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(fetchMessages.fulfilled, (state, action) => {
      state.isLoading = false;
      state.messages[action.payload.chatId] = action.payload.messages;
    });
    builder.addCase(fetchMessages.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });
    
    // Mark messages as read
    builder.addCase(markMessagesAsRead.fulfilled, (state, action) => {
      const { chatId } = action.payload;
      
      if (state.messages[chatId]) {
        state.messages[chatId] = state.messages[chatId].map(message => ({
          ...message,
          read: true,
        }));
      }
    });
  },
});

export const { setCurrentChat, addMessage, clearChatsError } = chatsSlice.actions;
export default chatsSlice.reducer;
