import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StackNavigationProp } from '@react-navigation/stack';
import { AuthStackParamList } from '../../navigation/AuthNavigator';
import { ROUTES } from '../../constants';
import Button from '../../components/shared/Button';
import Input from '../../components/shared/Input';
import theme from '../../theme';
import { useAppDispatch, useAppSelector } from '../../hooks/useRedux';
import { registerUser, clearError } from '../../store/slices/authSlice';

type SignupScreenNavigationProp = StackNavigationProp<
  AuthStackParamList,
  typeof ROUTES.SIGNUP
>;

interface SignupScreenProps {
  navigation: SignupScreenNavigationProp;
}

const SignupScreen: React.FC<SignupScreenProps> = ({ navigation }) => {
  const dispatch = useAppDispatch();
  const { isLoading, error } = useAppSelector((state) => state.auth);

  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  const [displayNameError, setDisplayNameError] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [confirmPasswordError, setConfirmPasswordError] = useState('');

  // Clear any existing auth errors when component mounts
  useEffect(() => {
    dispatch(clearError());
  }, [dispatch]);

  // Validate form
  const validateForm = () => {
    let isValid = true;

    // Display name validation
    if (!displayName.trim()) {
      setDisplayNameError('Display name is required');
      isValid = false;
    } else {
      setDisplayNameError('');
    }

    // Email validation
    if (!email.trim()) {
      setEmailError('Email is required');
      isValid = false;
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      setEmailError('Email is invalid');
      isValid = false;
    } else {
      setEmailError('');
    }

    // Password validation
    if (!password) {
      setPasswordError('Password is required');
      isValid = false;
    } else if (password.length < 6) {
      setPasswordError('Password must be at least 6 characters');
      isValid = false;
    } else {
      setPasswordError('');
    }

    // Confirm password validation
    if (password !== confirmPassword) {
      setConfirmPasswordError('Passwords do not match');
      isValid = false;
    } else {
      setConfirmPasswordError('');
    }

    return isValid;
  };

  // Handle signup
  const handleSignup = async () => {
    if (!validateForm()) return;

    const result = await dispatch(
      registerUser({
        displayName,
        email,
        password,
      })
    );

    if (registerUser.fulfilled.match(result)) {
      // Registration successful, navigate to payment intro screen
      navigation.navigate(ROUTES.PAYMENT_INTRO);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 64 : 0}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContainer}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.header}>
            <Text style={styles.title}>Create Account</Text>
            <Text style={styles.subtitle}>
              Join the Bonded community to connect with people in real life
            </Text>
          </View>

          <View style={styles.form}>
            <Input
              label="Display Name"
              placeholder="Enter your name"
              autoCapitalize="words"
              value={displayName}
              onChangeText={(text) => {
                setDisplayName(text);
                setDisplayNameError('');
              }}
              error={displayNameError}
              leftIcon="person-outline"
            />

            <Input
              label="Email"
              placeholder="Enter your email"
              keyboardType="email-address"
              autoCapitalize="none"
              autoComplete="email"
              value={email}
              onChangeText={(text) => {
                setEmail(text);
                setEmailError('');
              }}
              error={emailError}
              leftIcon="mail-outline"
            />

            <Input
              label="Password"
              placeholder="Create a password"
              secureTextEntry
              value={password}
              onChangeText={(text) => {
                setPassword(text);
                setPasswordError('');
                if (confirmPassword) {
                  setConfirmPasswordError(
                    text !== confirmPassword ? 'Passwords do not match' : ''
                  );
                }
              }}
              error={passwordError}
              leftIcon="lock-closed-outline"
            />

            <Input
              label="Confirm Password"
              placeholder="Confirm your password"
              secureTextEntry
              value={confirmPassword}
              onChangeText={(text) => {
                setConfirmPassword(text);
                setConfirmPasswordError(
                  text !== password ? 'Passwords do not match' : ''
                );
              }}
              error={confirmPasswordError}
              leftIcon="lock-closed-outline"
            />

            {error && <Text style={styles.errorText}>{error}</Text>}

            <Text style={styles.termsText}>
              By signing up, you agree to our{' '}
              <Text style={styles.termsLink}>Terms of Service</Text> and{' '}
              <Text style={styles.termsLink}>Privacy Policy</Text>.
            </Text>

            <Button
              title="Create Account"
              onPress={handleSignup}
              loading={isLoading}
              disabled={isLoading}
              fullWidth
              style={styles.signupButton}
            />

            <View style={styles.loginContainer}>
              <Text style={styles.loginText}>Already have an account?</Text>
              <TouchableOpacity
                onPress={() => navigation.navigate(ROUTES.LOGIN)}
              >
                <Text style={styles.loginLink}>Sign In</Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: theme.colors.white,
  },
  container: {
    flex: 1,
  },
  scrollContainer: {
    flexGrow: 1,
    padding: theme.spacing.l,
  },
  header: {
    marginTop: theme.spacing.l,
    marginBottom: theme.spacing.l,
  },
  title: {
    fontSize: theme.typography.fontSize.xxxl,
    fontWeight: 'bold',
    color: theme.colors.gray[900],
    marginBottom: theme.spacing.s,
  },
  subtitle: {
    fontSize: theme.typography.fontSize.m,
    color: theme.colors.gray[600],
  },
  form: {
    flex: 1,
  },
  errorText: {
    color: theme.colors.error.main,
    fontSize: theme.typography.fontSize.s,
    marginTop: theme.spacing.s,
  },
  termsText: {
    fontSize: theme.typography.fontSize.s,
    color: theme.colors.gray[600],
    marginTop: theme.spacing.m,
    marginBottom: theme.spacing.m,
  },
  termsLink: {
    color: theme.colors.primary[600],
    textDecorationLine: 'underline',
  },
  signupButton: {
    marginBottom: theme.spacing.l,
  },
  loginContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: theme.spacing.m,
  },
  loginText: {
    color: theme.colors.gray[600],
    fontSize: theme.typography.fontSize.m,
    marginRight: theme.spacing.xs,
  },
  loginLink: {
    color: theme.colors.primary[600],
    fontSize: theme.typography.fontSize.m,
    fontWeight: 'bold',
  },
});

export default SignupScreen;
