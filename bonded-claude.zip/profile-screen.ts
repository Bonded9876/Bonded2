import React, { useState } from 'react';
import {
  StyleSheet,
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Switch,
  Modal,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { BottomTabNavigationProp } from '@react-navigation/bottom-tabs';
import { CompositeNavigationProp } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { MainTabParamList } from '../../navigation/MainNavigator';
import { MainStackParamList } from '../../navigation/MainNavigator';
import { ROUTES, APP_VERSION } from '../../constants';
import { useAuth } from '../../hooks/useAuth';
import { useLocation } from '../../hooks/useLocation';
import { useAppDispatch, useAppSelector } from '../../hooks/useRedux';
import { signOutUser, updateUserProfile } from '../../store/slices/authSlice';
import Avatar from '../../components/shared/Avatar';
import Button from '../../components/shared/Button';
import Input from '../../components/shared/Input';
import Header from '../../components/shared/Header';
import theme from '../../theme';
import { uploadProfileImage } from '../../services/storageService'; // You'll need to implement this

type ProfileScreenNavigationProp = CompositeNavigationProp<
  BottomTabNavigationProp<MainTabParamList, typeof ROUTES.PROFILE>,
  StackNavigationProp<MainStackParamList>
>;

interface ProfileScreenProps {
  navigation: ProfileScreenNavigationProp;
}

const ProfileScreen: React.FC<ProfileScreenProps> = ({ navigation }) => {
  const dispatch = useAppDispatch();
  const { user, isLoading: authLoading } = useAuth();
  const { isLocationSharingEnabled, toggleLocationSharing } = useLocation();
  const { defaultTopics, userTopics } = useAppSelector((state) => state.topics);
  
  const [showEditModal, setShowEditModal] = useState(false);
  const [displayName, setDisplayName] = useState(user?.displayName || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [nameError, setNameError] = useState('');
  const [isUploading, setIsUploading] = useState(false);

  // Filter user's topics
  const userTopicDetails = defaultTopics.filter((topic) => 
    userTopics.includes(topic.id)
  );

  // Handle image picking
  const handlePickImage = async () => {
    try {
      // Request permission
      const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
      
      if (!permissionResult.granted) {
        Alert.alert('Permission Required', 'We need your permission to access your photos');
        return;
      }
      
      // Launch image picker
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });
      
      if (!result.canceled && result.assets && result.assets.length > 0) {
        const selectedImage = result.assets[0];
        
        // Upload image
        if (user) {
          setIsUploading(true);
          try {
            const imageUrl = await uploadProfileImage(selectedImage.uri, user.id);
            
            // Update user profile
            await dispatch(updateUserProfile({
              userId: user.id,
              data: { profileImage: imageUrl },
            })).unwrap();
            
            Alert.alert('Success', 'Profile image updated successfully');
          } catch (error) {
            console.error('Error uploading image:', error);
            Alert.alert('Error', 'Failed to update profile image');
          } finally {
            setIsUploading(false);
          }
        }
      }
    } catch (error) {
      console.error('Error picking image:', error);
      Alert.alert('Error', 'Something went wrong while selecting an image');
    }
  };

  // Handle saving profile edits
  const handleSaveProfile = async () => {
    // Validate form
    if (!displayName.trim()) {
      setNameError('Display name is required');
      return;
    }
    
    try {
      if (user) {
        await dispatch(updateUserProfile({
          userId: user.id,
          data: {
            displayName: displayName.trim(),
            bio: bio.trim(),
          },
        })).unwrap();
        
        setShowEditModal(false);
        Alert.alert('Success', 'Profile updated successfully');
      }
    } catch (error) {
      console.error('Error updating profile:', error);
      Alert.alert('Error', 'Failed to update profile');
    }
  };

  // Handle logout
  const handleLogout = async () => {
    Alert.alert(
      'Confirm Logout',
      'Are you sure you want to log out?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Logout',
          style: 'destructive',
          onPress: async () => {
            await dispatch(signOutUser());
          },
        },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <Header title="Profile" />
      
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Profile Header */}
        <View style={styles.profileHeader}>
          <TouchableOpacity
            onPress={handlePickImage}
            disabled={isUploading}
            style={styles.avatarContainer}
          >
            <Avatar
              uri={user?.profileImage}
              initials={user?.displayName}
              size="xl"
              backgroundColor={theme.colors.primary[600]}
            />
            
            {isUploading ? (
              <View style={styles.uploadingOverlay}>
                <ActivityIndicator color="#fff" />
              </View>
            ) : (
              <View style={styles.editAvatarButton}>
                <Ionicons name="camera" size={16} color="#fff" />
              </View>
            )}
          </TouchableOpacity>
          
          <Text style={styles.userName}>{user?.displayName}</Text>
          <Text style={styles.userEmail}>{user?.email}</Text>
          
          <Button
            title="Edit Profile"
            variant="outline"
            size="small"
            leftIcon="pencil"
            onPress={() => {
              setDisplayName(user?.displayName || '');
              setBio(user?.bio || '');
              setNameError('');
              setShowEditModal(true);
            }}
            style={styles.editButton}
          />
        </View>
        
        {/* Bio Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>About</Text>
          <Text style={styles.bioText}>
            {user?.bio || 'No bio yet. Tap "Edit Profile" to add one.'}
          </Text>
        </View>
        
        {/* Topics Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>My Topics</Text>
            <TouchableOpacity 
              style={styles.sectionAction}
              onPress={() => navigation.navigate(ROUTES.TOPICS)}
            >
              <Text style={styles.sectionActionText}>Manage</Text>
            </TouchableOpacity>
          </View>
          
          {userTopicDetails.length === 0 ? (
            <TouchableOpacity
              style={styles.emptyTopicsContainer}
              onPress={() => navigation.navigate(ROUTES.TOPICS)}
            >
              <Text style={styles.emptyTopicsText}>
                You haven't joined any topics yet. Tap here to explore topics.
              </Text>
            </TouchableOpacity>
          ) : (
            <View style={styles.topicsContainer}>
              {userTopicDetails.map((topic) => (
                <View key={topic.id} style={styles.topicChip}>
                  <View
                    style={[
                      styles.topicIcon,
                      { backgroundColor: topic.color || theme.colors.primary[600] },
                    ]}
                  >
                    <Ionicons
                      name={(topic.icon as keyof typeof Ionicons.glyphMap) || 'people'}
                      size={14}
                      color="#fff"
                    />
                  </View>
                  <Text style={styles.topicName}>{topic.name}</Text>
                </View>
              ))}
            </View>
          )}
        </View>
        
        {/* Settings Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Settings</Text>
          
          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Ionicons name="location" size={22} color={theme.colors.gray[600]} />
              <View style={styles.settingTextContainer}>
                <Text style={styles.settingTitle}>Location Sharing</Text>
                <Text style={styles.settingDescription}>
                  Allow other users to see your location on the map
                </Text>
              </View>
            </View>
            <Switch
              value={isLocationSharingEnabled}
              onValueChange={toggleLocationSharing}
              trackColor={{
                false: theme.colors.gray[300],
                true: theme.colors.primary[600],
              }}
              thumbColor={theme.colors.white}
            />
          </View>
          
          <TouchableOpacity
            style={styles.settingItemButton}
            onPress={() => navigation.navigate(ROUTES.NOTIFICATIONS)}
          >
            <View style={styles.settingInfo}>
              <Ionicons name="notifications" size={22} color={theme.colors.gray[600]} />
              <View style={styles.settingTextContainer}>
                <Text style={styles.settingTitle}>Notifications</Text>
                <Text style={styles.settingDescription}>
                  Manage notification preferences
                </Text>
              </View>
            </View>
            <Ionicons name="chevron-forward" size={22} color={theme.colors.gray[400]} />
          </TouchableOpacity>
          
          <TouchableOpacity
            style={styles.settingItemButton}
            onPress={() => navigation.navigate(ROUTES.SETTINGS)}
          >
            <View style={styles.settingInfo}>
              <Ionicons name="settings" size={22} color={theme.colors.gray[600]} />
              <View style={styles.settingTextContainer}>
                <Text style={styles.settingTitle}>App Settings</Text>
                <Text style={styles.settingDescription}>
                  Customize your app experience
                </Text>
              </View>
            </View>
            <Ionicons name="chevron-forward" size={22} color={theme.colors.gray[400]} />
          </TouchableOpacity>
        </View>
        
        {/* Payment Section (if not paid) */}
        {user && !user.hasPaid && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Complete Setup</Text>
            <View style={styles.paymentContainer}>
              <Text style={styles.paymentText}>
                Complete your one-time payment to unlock all Bonded features
              </Text>
              <Button
                title="Pay Now"
                onPress={() => navigation.navigate(ROUTES.PAYMENT)}
                style={styles.paymentButton}
              />
            </View>
          </View>
        )}
        
        {/* Support Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Support</Text>
          
          <TouchableOpacity
            style={styles.settingItemButton}
            onPress={() => {
              // Navigate to help/support screen
              // For now, just show an alert
              Alert.alert(
                'Help & Support',
                'For support, please contact support@bondedapp.com'
              );
            }}
          >
            <View style={styles.settingInfo}>
              <Ionicons name="help-circle" size={22} color={theme.colors.gray[600]} />
              <Text style={styles.settingTitle}>Help & FAQ</Text>
            </View>
            <Ionicons name="chevron-forward" size={22} color={theme.colors.gray[400]} />
          </TouchableOpacity>
          
          <TouchableOpacity
            style={styles.settingItemButton}
            onPress={() => {
              // Navigate to privacy policy
              // For now, just show an alert
              Alert.alert(
                'Privacy Policy',
                'Open privacy policy page'
              );
            }}
          >
            <View style={styles.settingInfo}>
              <Ionicons name="shield" size={22} color={theme.colors.gray[600]} />
              <Text style={styles.settingTitle}>Privacy Policy</Text>
            </View>
            <Ionicons name="chevron-forward" size={22} color={theme.colors.gray[400]} />
          </TouchableOpacity>
          
          <TouchableOpacity
            style={styles.settingItemButton}
            onPress={() => {
              // Navigate to terms of service
              // For now, just show an alert
              Alert.alert(
                'Terms of Service',
                'Open terms of service page'
              );
            }}
          >
            <View style={styles.settingInfo}>
              <Ionicons name="document-text" size={22} color={theme.colors.gray[600]} />
              <Text style={styles.settingTitle}>Terms of Service</Text>
            </View>
            <Ionicons name="chevron-forward" size={22} color={theme.colors.gray[400]} />
          </TouchableOpacity>
        </View>
        
        {/* Logout Button */}
        <Button
          title="Log Out"
          variant="danger"
          onPress={handleLogout}
          loading={authLoading}
          disabled={authLoading}
          fullWidth
          style={styles.logoutButton}
        />
        
        <Text style={styles.versionText}>Bonded v{APP_VERSION}</Text>
      </ScrollView>
      
      {/* Edit Profile Modal */}
      <Modal
        visible={showEditModal}
        animationType="slide"
        transparent
        onRequestClose={() => setShowEditModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Edit Profile</Text>
              <TouchableOpacity onPress={() => setShowEditModal(false)}>
                <Ionicons name="close" size={24} color={theme.colors.gray[500]} />
              </TouchableOpacity>
            </View>
            
            <Input
              label="Display Name"
              value={displayName}
              onChangeText={(text) => {
                setDisplayName(text);
                if (text.trim()) setNameError('');
              }}
              error={nameError}
              maxLength={50}
            />
            
            <Input
              label="Bio"
              value={bio}
              onChangeText={setBio}
              multiline
              numberOfLines={5}
              maxLength={250}
              placeholder="Tell us a bit about yourself..."
              inputStyle={styles.bioInput}
            />
            
            <View style={styles.modalActions}>
              <Button
                title="Cancel"
                variant="ghost"
                onPress={() => setShowEditModal(false)}
                style={styles.modalCancelButton}
              />
              
              <Button
                title="Save"
                onPress={handleSaveProfile}
                loading={authLoading}
                disabled={authLoading}
                style={styles.modalSaveButton}
              />
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.white,
  },
  profileHeader: {
    alignItems: 'center',
    padding: theme.spacing.l,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.gray[200],
  },
  avatarContainer: {
    position: 'relative',
    marginBottom: theme.spacing.m,
  },
  uploadingOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    borderRadius: 9999,
  },
  editAvatarButton: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: theme.colors.primary[600],
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: theme.colors.white,
  },
  userName: {
    fontSize: theme.typography.fontSize.xl,
    fontWeight: 'bold',
    color: theme.colors.gray[900],
    marginBottom: theme.spacing.xs,
  },
  userEmail: {
    fontSize: theme.typography.fontSize.s,
    color: theme.colors.gray[600],
    marginBottom: theme.spacing.m,
  },
  editButton: {
    marginBottom: theme.spacing.s,
  },
  section: {
    padding: theme.spacing.l,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.gray[200],
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing.m,
  },
  sectionTitle: {
    fontSize: theme.typography.fontSize.l,
    fontWeight: 'bold',
    color: theme.colors.gray[900],
    marginBottom: theme.spacing.m,
  },
  sectionAction: {
    padding: theme.spacing.xs,
  },
  sectionActionText: {
    fontSize: theme.typography.fontSize.s,
    color: theme.colors.primary[600],
    fontWeight: '500',
  },
  bioText: {
    fontSize: theme.typography.fontSize.m,
    color: theme.colors.gray[800],
    lineHeight: 20,
  },
  emptyTopicsContainer: {
    backgroundColor: theme.colors.gray[100],
    padding: theme.spacing.m,
    borderRadius: theme.borders.radius.m,
    alignItems: 'center',
  },
  emptyTopicsText: {
    fontSize: theme.typography.fontSize.s,
    color: theme.colors.gray[600],
    textAlign: 'center',
  },
  topicsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  topicChip: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.gray[100],
    paddingVertical: theme.spacing.xs,
    paddingHorizontal: theme.spacing.m,
    borderRadius: theme.borders.radius.l,
    marginRight: theme.spacing.s,
    marginBottom: theme.spacing.s,
  },
  topicIcon: {
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: theme.spacing.xs,
  },
  topicName: {
    fontSize: theme.typography.fontSize.s,
    color: theme.colors.gray[800],
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: theme.spacing.m,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.gray[200],
  },
  settingItemButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: theme.spacing.m,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.gray[200],
  },
  settingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingTextContainer: {
    marginLeft: theme.spacing.m,
    flex: 1,
  },
  settingTitle: {
    fontSize: theme.typography.fontSize.m,
    color: theme.colors.gray[900],
    marginLeft: theme.spacing.m,
  },
  settingDescription: {
    fontSize: theme.typography.fontSize.xs,
    color: theme.colors.gray[600],
    marginTop: 2,
  },
  paymentContainer: {
    backgroundColor: theme.colors.primary[50],
    borderRadius: theme.borders.radius.m,
    padding: theme.spacing.m,
  },
  paymentText: {
    fontSize: theme.typography.fontSize.m,
    color: theme.colors.primary[900],
    marginBottom: theme.spacing.m,
  },
  paymentButton: {
    alignSelf: 'flex-start',
  },
  logoutButton: {
    marginHorizontal: theme.spacing.l,
    marginVertical: theme.spacing.l,
  },
  versionText: {
    textAlign: 'center',
    fontSize: theme.typography.fontSize.xs,
    color: theme.colors.gray[500],
    marginBottom: theme.spacing.xl,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContainer: {
    backgroundColor: theme.colors.white,
    borderTopLeftRadius: theme.borders.radius.l,
    borderTopRightRadius: theme.borders.radius.l,
    padding: theme.spacing.l,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing.l,
  },
  modalTitle: {
    fontSize: theme.typography.fontSize.l,
    fontWeight: 'bold',
    color: theme.colors.gray[900],
  },
  bioInput: {
    height: 100,
    textAlignVertical: 'top',
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: theme.spacing.l,
  },
  modalCancelButton: {
    marginRight: theme.spacing.m,
  },
  modalSaveButton: {
    minWidth: 100,
  },
});

export default ProfileScreen;
