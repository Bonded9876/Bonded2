import { configureStore } from '@reduxjs/toolkit';
import authReducer from './slices/authSlice';
import locationReducer from './slices/locationSlice';
import topicsReducer from './slices/topicsSlice';
import chatsReducer from './slices/chatsSlice';

export const store = configureStore({
  reducer: {
    auth: authReducer,
    location: locationReducer,
    topics: topicsReducer,
    chats: chatsReducer,
  },
  middleware: (getDefaultMiddleware) => 
    getDefaultMiddleware({
      serializableCheck: {
        // Ignore these paths in the state for non-serializable values
        ignoredActions: ['auth/updateUser', 'location/updateLocation'],
        ignoredPaths: ['auth.user.createdAt', 'location.currentLocation'],
      },
    }),
});

// Infer the RootState and AppDispatch types from the store itself
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
