import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { ROUTES } from '../constants';

// Import screens
import MapScreen from '../screens/main/MapScreen';
import TopicsScreen from '../screens/main/TopicsScreen';
import ChatsScreen from '../screens/main/ChatsScreen';
import ProfileScreen from '../screens/main/ProfileScreen';
import MeetupsScreen from '../screens/main/MeetupsScreen';
import ChatDetailScreen from '../screens/main/ChatDetailScreen';
import TopicDetailScreen from '../screens/main/TopicDetailScreen';
import UserProfileScreen from '../screens/main/UserProfileScreen';
import SettingsScreen from '../screens/main/SettingsScreen';
import NotificationsScreen from '../screens/main/NotificationsScreen';
import CreateTopicScreen from '../screens/main/CreateTopicScreen';
import CreateMeetupScreen from '../screens/main/CreateMeetupScreen';

// Define tab navigator parameter list
export type MainTabParamList = {
  [ROUTES.MAP]: undefined;
  [ROUTES.TOPICS]: undefined;
  [ROUTES.CHATS]: undefined;
  [ROUTES.MEETUPS]: undefined;
  [ROUTES.PROFILE]: undefined;
};

// Define stack navigator parameter list
export type MainStackParamList = {
  [ROUTES.TABS]: undefined;
  [ROUTES.CHAT_DETAIL]: { chatId?: string; userId?: string };
  [ROUTES.TOPIC_DETAIL]: { topicId: string };
  [ROUTES.USER_PROFILE]: { userId: string };
  [ROUTES.SETTINGS]: undefined;
  [ROUTES.NOTIFICATIONS]: undefined;
  [ROUTES.CREATE_TOPIC]: undefined;
  [ROUTES.CREATE_MEETUP]: undefined;
};

const Tab = createBottomTabNavigator<MainTabParamList>();
const Stack = createStackNavigator<MainStackParamList>();

// Tab Navigator
const TabNavigator = () => {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarIcon: ({ focused, color, size }) => {
          let iconName: keyof typeof Ionicons.glyphMap = 'help-outline';

          if (route.name === ROUTES.MAP) {
            iconName = focused ? 'map' : 'map-outline';
          } else if (route.name === ROUTES.TOPICS) {
            iconName = focused ? 'list' : 'list-outline';
          } else if (route.name === ROUTES.CHATS) {
            iconName = focused ? 'chatbubbles' : 'chatbubbles-outline';
          } else if (route.name === ROUTES.MEETUPS) {
            iconName = focused ? 'calendar' : 'calendar-outline';
          } else if (route.name === ROUTES.PROFILE) {
            iconName = focused ? 'person' : 'person-outline';
          }

          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: '#4f46e5', // Indigo-600
        tabBarInactiveTintColor: '#64748b', // Slate-500
        tabBarStyle: {
          borderTopWidth: 1,
          borderTopColor: '#e2e8f0', // Slate-200
        },
      })}
    >
      <Tab.Screen name={ROUTES.MAP} component={MapScreen} />
      <Tab.Screen name={ROUTES.TOPICS} component={TopicsScreen} />
      <Tab.Screen name={ROUTES.CHATS} component={ChatsScreen} />
      <Tab.Screen name={ROUTES.MEETUPS} component={MeetupsScreen} />
      <Tab.Screen name={ROUTES.PROFILE} component={ProfileScreen} />
    </Tab.Navigator>
  );
};

// Main Navigator (including tabs and modal screens)
const MainNavigator = () => {
  return (
    <Stack.Navigator
      initialRouteName={ROUTES.TABS}
      screenOptions={{
        headerShown: false,
        cardStyle: { backgroundColor: 'white' },
      }}
    >
      <Stack.Screen name={ROUTES.TABS} component={TabNavigator} />
      <Stack.Screen name={ROUTES.CHAT_DETAIL} component={ChatDetailScreen} />
      <Stack.Screen name={ROUTES.TOPIC_DETAIL} component={TopicDetailScreen} />
      <Stack.Screen name={ROUTES.USER_PROFILE} component={UserProfileScreen} />
      <Stack.Screen name={ROUTES.SETTINGS} component={SettingsScreen} />
      <Stack.Screen name={ROUTES.NOTIFICATIONS} component={NotificationsScreen} />
      <Stack.Screen name={ROUTES.CREATE_TOPIC} component={CreateTopicScreen} />
      <Stack.Screen name={ROUTES.CREATE_MEETUP} component={CreateMeetupScreen} />
    </Stack.Navigator>
  );
};

export default MainNavigator;
