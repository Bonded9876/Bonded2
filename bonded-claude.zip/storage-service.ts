import { getStorage, ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { storage } from './firebase';

/**
 * Uploads a profile image to Firebase Storage
 * @param uri The local image URI to upload
 * @param userId The user ID to associate with the image
 * @returns A Promise that resolves to the download URL of the uploaded image
 */
export const uploadProfileImage = async (uri: string, userId: string): Promise<string> => {
  try {
    // Convert the URI to a Blob
    const response = await fetch(uri);
    const blob = await response.blob();
    
    // Create a storage reference
    const storageRef = ref(storage, `profile_images/${userId}/${Date.now()}`);
    
    // Upload the file
    const uploadTask = uploadBytesResumable(storageRef, blob);
    
    // Return a promise that resolves with the download URL
    return new Promise((resolve, reject) => {
      uploadTask.on(
        'state_changed',
        (snapshot) => {
          // You can track upload progress here if needed
          const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          console.log(`Upload is ${progress}% done`);
        },
        (error) => {
          // Handle unsuccessful uploads
          reject(error);
        },
        async () => {
          // Handle successful upload
          try {
            const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
            resolve(downloadURL);
          } catch (error) {
            reject(error);
          }
        }
      );
    });
  } catch (error) {
    console.error('Error uploading image:', error);
    throw error;
  }
};

/**
 * Uploads a file to Firebase Storage
 * @param uri The local file URI to upload
 * @param path The storage path to upload to
 * @returns A Promise that resolves to the download URL of the uploaded file
 */
export const uploadFile = async (uri: string, path: string): Promise<string> => {
  try {
    // Convert the URI to a Blob
    const response = await fetch(uri);
    const blob = await response.blob();
    
    // Create a storage reference
    const storageRef = ref(storage, path);
    
    // Upload the file
    const uploadTask = uploadBytesResumable(storageRef, blob);
    
    // Return a promise that resolves with the download URL
    return new Promise((resolve, reject) => {
      uploadTask.on(
        'state_changed',
        (snapshot) => {
          // You can track upload progress here if needed
          const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          console.log(`Upload is ${progress}% done`);
        },
        (error) => {
          // Handle unsuccessful uploads
          reject(error);
        },
        async () => {
          // Handle successful upload
          try {
            const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
            resolve(downloadURL);
          } catch (error) {
            reject(error);
          }
        }
      );
    });
  } catch (error) {
    console.error('Error uploading file:', error);
    throw error;
  }
};
