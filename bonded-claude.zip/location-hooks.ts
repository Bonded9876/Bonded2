import { useEffect, useRef } from 'react';
import * as Location from 'expo-location';
import { useAppDispatch, useAppSelector } from './useRedux';
import { 
  requestLocationPermission,
  getCurrentLocation,
  watchUserLocation,
  updateUserLocation,
  toggleLocationSharing,
} from '../store/slices/locationSlice';
import { useAuth } from './useAuth';

export const useLocation = () => {
  const dispatch = useAppDispatch();
  const { user } = useAuth();
  const { 
    currentLocation, 
    isLoading, 
    error, 
    isPermissionGranted,
    isLocationSharingEnabled,
  } = useAppSelector(state => state.location);
  
  const locationWatcherRef = useRef<() => void | null>(null);

  // Initialize location tracking
  useEffect(() => {
    // Request location permission when component mounts
    dispatch(requestLocationPermission())
      .unwrap()
      .then(granted => {
        if (granted) {
          // Get initial location
          dispatch(getCurrentLocation());
          
          // Start watching location if user is logged in
          if (user) {
            dispatch(watchUserLocation(user.id))
              .unwrap()
              .then(unsubscribe => {
                locationWatcherRef.current = unsubscribe;
              });
          }
        }
      });
      
    // Clean up location watcher
    return () => {
      if (locationWatcherRef.current) {
        locationWatcherRef.current();
      }
    };
  }, [dispatch, user?.id]);

  // Refresh location on demand
  const refreshLocation = async () => {
    if (!isPermissionGranted) {
      await dispatch(requestLocationPermission());
    }
    
    if (isPermissionGranted) {
      await dispatch(getCurrentLocation());
    }
  };

  // Toggle location sharing
  const handleToggleLocationSharing = (enabled: boolean) => {
    dispatch(toggleLocationSharing(enabled));
    
    // If turning location sharing back on and we have location data, update it in Firestore
    if (enabled && currentLocation && user) {
      dispatch(updateUserLocation({ 
        userId: user.id, 
        location: currentLocation 
      }));
    }
  };

  return {
    currentLocation,
    isLoading,
    error,
    isPermissionGranted,
    isLocationSharingEnabled,
    refreshLocation,
    toggleLocationSharing: handleToggleLocationSharing,
  };
};
