import { firestore } from '../services/firebase';
import {
  collection,
  query,
  where,
  getDocs,
  doc,
  getDoc,
  GeoPoint,
  orderBy,
  limit,
} from 'firebase/firestore';
import { User, GeoPoint as GeoPointType } from '../types';

/**
 * Fetches a user by their ID
 * @param userId The ID of the user to fetch
 * @returns Promise with the user data
 */
export const fetchUserById = async (userId: string): Promise<User | null> => {
  try {
    const userRef = doc(firestore, 'users', userId);
    const userDoc = await getDoc(userRef);
    
    if (!userDoc.exists()) {
      return null;
    }
    
    const userData = userDoc.data();
    
    return {
      id: userDoc.id,
      email: userData.email,
      displayName: userData.displayName,
      bio: userData.bio || '',
      profileImage: userData.profileImage || null,
      createdAt: userData.createdAt.toDate(),
      hasPaid: userData.hasPaid || false,
      topics: userData.topics || [],
      location: userData.location
        ? {
            latitude: userData.location.latitude,
            longitude: userData.location.longitude,
          }
        : undefined,
      lastLocationUpdate: userData.lastLocationUpdate
        ? userData.lastLocationUpdate.toDate()
        : undefined,
    };
  } catch (error) {
    console.error('Error fetching user:', error);
    throw error;
  }
};

/**
 * Interface for the nearby users fetch parameters
 */
interface NearbyUsersParams {
  latitude: number;
  longitude: number;
  maxDistance: number;
  topicIds?: string[];
  limit?: number;
}

/**
 * Fetches users near a specific location
 * @param params The search parameters
 * @returns Promise with an array of nearby users
 */
export const fetchNearbyUsers = async ({
  latitude,
  longitude,
  maxDistance,
  topicIds,
  limit: resultLimit = 50,
}: NearbyUsersParams): Promise<any[]> => {
  try {
    // In a real app, this would use a geospatial query
    // Unfortunately, Firestore doesn't support geospatial queries directly
    // You would typically use a service like GeoFirestore, Firebase Functions, or Algolia
    
    // For this prototype, we'll fetch all users and filter them client-side
    // This is NOT efficient for a production app
    const usersRef = collection(firestore, 'users');
    
    // Only get users who have paid and have location data
    const q = query(
      usersRef,
      where('hasPaid', '==', true),
      // You can't query for non-null fields in Firestore directly,
      // so we'll filter out users without location in our code
    );
    
    const snapshot = await getDocs(q);
    
    const nearbyUsers: any[] = [];
    
    snapshot.forEach((userDoc) => {
      const userData = userDoc.data();
      
      // Skip users without location
      if (!userData.location) return;
      
      // Calculate distance using Haversine formula
      const distance = calculateDistance(
        latitude,
        longitude,
        userData.location.latitude,
        userData.location.longitude
      );
      
      // Filter by distance
      if (distance <= maxDistance) {
        // Filter by topics if specified
        if (topicIds && topicIds.length > 0) {
          // Check if user has any of the requested topics
          const hasMatchingTopic = userData.topics && userData.topics.some((topic: string) =>
            topicIds.includes(topic)
          );
          
          if (!hasMatchingTopic) return;
        }
        
        // Add to results
        nearbyUsers.push({
          id: userDoc.id,
          displayName: userData.displayName,
          profileImage: userData.profileImage,
          bio: userData.bio,
          distance,
          location: {
            latitude: userData.location.latitude,
            longitude: userData.location.longitude,
          },
          topics: userData.topics || [],
          // Add any other user data you need
        });
      }
    });
    
    // Sort by distance and limit results
    return nearbyUsers
      .sort((a, b) => a.distance - b.distance)
      .slice(0, resultLimit);
  } catch (error) {
    console.error('Error fetching nearby users:', error);
    throw error;
  }
};

/**
 * Calculate distance between two coordinates using the Haversine formula
 * @param lat1 Latitude of first point
 * @param lon1 Longitude of first point
 * @param lat2 Latitude of second point
 * @param lon2 Longitude of second point
 * @returns Distance in kilometers
 */
const calculateDistance = (
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number => {
  const R = 6371; // Radius of the Earth in kilometers
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c; // Distance in km
  
  return distance;
};

/**
 * Convert degrees to radians
 * @param deg Degrees
 * @returns Radians
 */
const deg2rad = (deg: number): number => {
  return deg * (Math.PI / 180);
};
