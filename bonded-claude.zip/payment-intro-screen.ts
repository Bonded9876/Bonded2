import React from 'react';
import {
  StyleSheet,
  View,
  Text,
  ScrollView,
  Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StackNavigationProp } from '@react-navigation/stack';
import { Ionicons } from '@expo/vector-icons';
import { AuthStackParamList } from '../../navigation/AuthNavigator';
import { ROUTES, PAYMENT_AMOUNT, PAYMENT_AMOUNT_USD } from '../../constants';
import Button from '../../components/shared/Button';
import theme from '../../theme';

type PaymentIntroScreenNavigationProp = StackNavigationProp<
  AuthStackParamList,
  typeof ROUTES.PAYMENT_INTRO
>;

interface PaymentIntroScreenProps {
  navigation: PaymentIntroScreenNavigationProp;
}

const PaymentIntroScreen: React.FC<PaymentIntroScreenProps> = ({ navigation }) => {
  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView
        contentContainerStyle={styles.scrollContainer}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Text style={styles.title}>Join the Community</Text>
          <Text style={styles.subtitle}>
            One-time payment to connect with real people in real life
          </Text>
        </View>

        <View style={styles.pricingContainer}>
          <Text style={styles.price}>{PAYMENT_AMOUNT.toLocaleString()} Ft</Text>
          <Text style={styles.priceSubtitle}>or ${PAYMENT_AMOUNT_USD} USD</Text>
          <View style={styles.oneTimeContainer}>
            <Text style={styles.oneTimeText}>One-time payment only</Text>
          </View>
        </View>

        <View style={styles.featuresContainer}>
          <Text style={styles.featuresTitle}>What you get:</Text>

          <View style={styles.featureItem}>
            <Ionicons
              name="checkmark-circle"
              size={24}
              color={theme.colors.success.main}
            />
            <Text style={styles.featureText}>
              Access to the map showing nearby users
            </Text>
          </View>

          <View style={styles.featureItem}>
            <Ionicons
              name="checkmark-circle"
              size={24}
              color={theme.colors.success.main}
            />
            <Text style={styles.featureText}>
              Join interest topics and find like-minded people
            </Text>
          </View>

          <View style={styles.featureItem}>
            <Ionicons
              name="checkmark-circle"
              size={24}
              color={theme.colors.success.main}
            />
            <Text style={styles.featureText}>
              Create custom topics and groups for your interests
            </Text>
          </View>

          <View style={styles.featureItem}>
            <Ionicons
              name="checkmark-circle"
              size={24}
              color={theme.colors.success.main}
            />
            <Text style={styles.featureText}>
              Real-time messaging with other users
            </Text>
          </View>

          <View style={styles.featureItem}>
            <Ionicons
              name="checkmark-circle"
              size={24}
              color={theme.colors.success.main}
            />
            <Text style={styles.featureText}>
              Lifetime access to future updates
            </Text>
          </View>
        </View>

        <View style={styles.whyContainer}>
          <Text style={styles.whyTitle}>Why we charge?</Text>
          <Text style={styles.whyText}>
            Unlike other social apps, we don't sell your data or show ads.
            A one-time fee helps maintain quality users and provide a better
            experience for our community.
          </Text>
        </View>

        <Button
          title="Continue to Payment"
          onPress={() => navigation.navigate(ROUTES.PAYMENT)}
          fullWidth
          style={styles.paymentButton}
        />

        <Button
          title="Complete profile first"
          onPress={() => navigation.navigate(ROUTES.PROFILE_SETUP)}
          variant="ghost"
          fullWidth
        />

        <View style={styles.securityNote}>
          <Ionicons name="shield-checkmark" size={20} color={theme.colors.gray[500]} />
          <Text style={styles.securityText}>
            Secure payment process. Your information is protected.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: theme.colors.white,
  },
  scrollContainer: {
    flexGrow: 1,
    padding: theme.spacing.l,
  },
  header: {
    marginTop: theme.spacing.l,
    marginBottom: theme.spacing.l,
  },
  title: {
    fontSize: theme.typography.fontSize.xxl,
    fontWeight: 'bold',
    color: theme.colors.gray[900],
    marginBottom: theme.spacing.s,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: theme.typography.fontSize.m,
    color: theme.colors.gray[600],
    textAlign: 'center',
  },
  pricingContainer: {
    alignItems: 'center',
    backgroundColor: theme.colors.gray[50],
    borderRadius: theme.borders.radius.l,
    padding: theme.spacing.l,
    marginBottom: theme.spacing.l,
  },
  price: {
    fontSize: 42,
    fontWeight: 'bold',
    color: theme.colors.primary[600],
  },
  priceSubtitle: {
    fontSize: theme.typography.fontSize.m,
    color: theme.colors.gray[600],
    marginTop: theme.spacing.xs,
  },
  oneTimeContainer: {
    backgroundColor: theme.colors.success.light,
    paddingHorizontal: theme.spacing.m,
    paddingVertical: theme.spacing.xs,
    borderRadius: 20,
    marginTop: theme.spacing.m,
  },
  oneTimeText: {
    color: theme.colors.success.dark,
    fontWeight: 'bold',
    fontSize: theme.typography.fontSize.s,
  },
  featuresContainer: {
    marginBottom: theme.spacing.l,
  },
  featuresTitle: {
    fontSize: theme.typography.fontSize.l,
    fontWeight: 'bold',
    color: theme.colors.gray[900],
    marginBottom: theme.spacing.m,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: theme.spacing.m,
  },
  featureText: {
    fontSize: theme.typography.fontSize.m,
    color: theme.colors.gray[800],
    marginLeft: theme.spacing.m,
    flex: 1,
  },
  whyContainer: {
    backgroundColor: theme.colors.gray[50],
    borderRadius: theme.borders.radius.m,
    padding: theme.spacing.l,
    marginBottom: theme.spacing.l,
  },
  whyTitle: {
    fontSize: theme.typography.fontSize.m,
    fontWeight: 'bold',
    color: theme.colors.gray[900],
    marginBottom: theme.spacing.s,
  },
  whyText: {
    fontSize: theme.typography.fontSize.s,
    color: theme.colors.gray[700],
    lineHeight: 20,
  },
  paymentButton: {
    marginBottom: theme.spacing.m,
  },
  securityNote: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: theme.spacing.l,
    marginBottom: theme.spacing.m,
  },
  securityText: {
    fontSize: theme.typography.fontSize.xs,
    color: theme.colors.gray[500],
    marginLeft: theme.spacing.xs,
  },
});

export default PaymentIntroScreen;
