import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc,
  updateDoc,
  query,
  where,
  arrayUnion,
  arrayRemove,
  serverTimestamp,
} from 'firebase/firestore';
import { firestore, firestoreConverter } from '../../services/firebase';
import { Topic, CustomTopic } from '../../types';
import { DEFAULT_TOPICS } from '../../constants';

interface TopicsState {
  defaultTopics: Topic[];
  customTopics: CustomTopic[];
  userTopics: string[];
  isLoading: boolean;
  error: string | null;
}

// Initial state
const initialState: TopicsState = {
  defaultTopics: [],
  customTopics: [],
  userTopics: [],
  isLoading: false,
  error: null,
};

// Fetch default topics
export const fetchDefaultTopics = createAsyncThunk(
  'topics/fetchDefault',
  async (_, { rejectWithValue }) => {
    try {
      const topicsRef = collection(firestore, 'topics');
      const snapshot = await getDocs(topicsRef);
      
      // If no topics in Firestore, use default ones
      if (snapshot.empty) {
        return DEFAULT_TOPICS;
      }
      
      const topics: Topic[] = [];
      snapshot.forEach((doc) => {
        topics.push({
          id: doc.id,
          ...doc.data() as Omit<Topic, 'id'>,
        });
      });
      
      return topics;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Fetch user topics
export const fetchUserTopics = createAsyncThunk(
  'topics/fetchUserTopics',
  async (userId: string, { rejectWithValue }) => {
    try {
      const userRef = doc(firestore, 'users', userId);
      const userDoc = await getDoc(userRef);
      
      if (!userDoc.exists()) {
        throw new Error('User not found');
      }
      
      const userData = userDoc.data();
      return userData.topics || [];
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Fetch custom topics for user
export const fetchCustomTopics = createAsyncThunk(
  'topics/fetchCustom',
  async (userId: string, { rejectWithValue }) => {
    try {
      const topicsRef = collection(firestore, 'customTopics');
      const q = query(
        topicsRef,
        where('members', 'array-contains', userId)
      );
      
      const snapshot = await getDocs(q);
      
      const topics: CustomTopic[] = [];
      snapshot.forEach((doc) => {
        topics.push({
          id: doc.id,
          ...doc.data() as Omit<CustomTopic, 'id'>,
        });
      });
      
      return topics;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Join a topic
export const joinTopic = createAsyncThunk(
  'topics/join',
  async ({ userId, topicId }: { userId: string; topicId: string }, { rejectWithValue }) => {
    try {
      const userRef = doc(firestore, 'users', userId);
      
      await updateDoc(userRef, {
        topics: arrayUnion(topicId),
      });
      
      // Update topic members count
      const topicRef = doc(firestore, 'topics', topicId);
      const topicDoc = await getDoc(topicRef);
      
      if (topicDoc.exists()) {
        await updateDoc(topicRef, {
          membersCount: (topicDoc.data().membersCount || 0) + 1,
        });
      }
      
      return topicId;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Leave a topic
export const leaveTopic = createAsyncThunk(
  'topics/leave',
  async ({ userId, topicId }: { userId: string; topicId: string }, { rejectWithValue }) => {
    try {
      const userRef = doc(firestore, 'users', userId);
      
      await updateDoc(userRef, {
        topics: arrayRemove(topicId),
      });
      
      // Update topic members count
      const topicRef = doc(firestore, 'topics', topicId);
      const topicDoc = await getDoc(topicRef);
      
      if (topicDoc.exists() && topicDoc.data().membersCount > 0) {
        await updateDoc(topicRef, {
          membersCount: topicDoc.data().membersCount - 1,
        });
      }
      
      return topicId;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Create a custom topic
export const createCustomTopic = createAsyncThunk(
  'topics/createCustom',
  async ({ 
    userId, 
    topicData 
  }: { 
    userId: string; 
    topicData: Omit<CustomTopic, 'id' | 'createdBy' | 'createdAt' | 'members'> 
  }, { rejectWithValue }) => {
    try {
      // Reference for new custom topic
      const topicsRef = collection(firestore, 'customTopics');
      const newTopicRef = doc(topicsRef);
      
      const newTopic: Omit<CustomTopic, 'id'> = {
        ...topicData,
        createdBy: userId,
        createdAt: new Date(),
        members: [userId],
        membersCount: 1,
      };
      
      await setDoc(newTopicRef, {
        ...newTopic,
        createdAt: serverTimestamp(),
      });
      
      return {
        id: newTopicRef.id,
        ...newTopic,
      } as CustomTopic;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Join a custom topic
export const joinCustomTopic = createAsyncThunk(
  'topics/joinCustom',
  async ({ 
    userId, 
    topicId 
  }: { 
    userId: string; 
    topicId: string 
  }, { rejectWithValue }) => {
    try {
      const topicRef = doc(firestore, 'customTopics', topicId);
      const topicDoc = await getDoc(topicRef);
      
      if (!topicDoc.exists()) {
        throw new Error('Topic not found');
      }
      
      const topicData = topicDoc.data();
      
      // Check if topic is private
      if (topicData.isPrivate && !topicData.invitedUsers?.includes(userId) && topicData.createdBy !== userId) {
        throw new Error('This topic is private and requires an invitation');
      }
      
      // Add user to topic members
      await updateDoc(topicRef, {
        members: arrayUnion(userId),
        membersCount: (topicData.membersCount || 0) + 1,
        ...(topicData.invitedUsers?.includes(userId) ? {
          invitedUsers: arrayRemove(userId)
        } : {})
      });
      
      return {
        id: topicId,
        ...topicData,
        members: [...(topicData.members || []), userId],
      } as CustomTopic;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Leave a custom topic
export const leaveCustomTopic = createAsyncThunk(
  'topics/leaveCustom',
  async ({ 
    userId, 
    topicId 
  }: { 
    userId: string; 
    topicId: string 
  }, { rejectWithValue }) => {
    try {
      const topicRef = doc(firestore, 'customTopics', topicId);
      const topicDoc = await getDoc(topicRef);
      
      if (!topicDoc.exists()) {
        throw new Error('Topic not found');
      }
      
      const topicData = topicDoc.data();
      
      // Remove user from topic members
      await updateDoc(topicRef, {
        members: arrayRemove(userId),
        membersCount: Math.max((topicData.membersCount || 1) - 1, 0),
      });
      
      return topicId;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Topics slice
const topicsSlice = createSlice({
  name: 'topics',
  initialState,
  reducers: {
    clearTopicsError: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    // Fetch default topics
    builder.addCase(fetchDefaultTopics.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(fetchDefaultTopics.fulfilled, (state, action) => {
      state.isLoading = false;
      state.defaultTopics = action.payload;
    });
    builder.addCase(fetchDefaultTopics.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });
    
    // Fetch user topics
    builder.addCase(fetchUserTopics.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(fetchUserTopics.fulfilled, (state, action) => {
      state.isLoading = false;
      state.userTopics = action.payload;
    });
    builder.addCase(fetchUserTopics.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });
    
    // Fetch custom topics
    builder.addCase(fetchCustomTopics.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(fetchCustomTopics.fulfilled, (state, action) => {
      state.isLoading = false;
      state.customTopics = action.payload;
    });
    builder.addCase(fetchCustomTopics.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });
    
    // Join topic
    builder.addCase(joinTopic.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(joinTopic.fulfilled, (state, action) => {
      state.isLoading = false;
      state.userTopics.push(action.payload);
    });
    builder.addCase(joinTopic.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });
    
    // Leave topic
    builder.addCase(leaveTopic.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(leaveTopic.fulfilled, (state, action) => {
      state.isLoading = false;
      state.userTopics = state.userTopics.filter(id => id !== action.payload);
    });
    builder.addCase(leaveTopic.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });
    
    // Create custom topic
    builder.addCase(createCustomTopic.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(createCustomTopic.fulfilled, (state, action) => {
      state.isLoading = false;
      state.customTopics.push(action.payload);
    });
    builder.addCase(createCustomTopic.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });
    
    // Join custom topic
    builder.addCase(joinCustomTopic.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(joinCustomTopic.fulfilled, (state, action) => {
      state.isLoading = false;
      const existingIndex = state.customTopics.findIndex(t => t.id === action.payload.id);
      if (existingIndex >= 0) {
        state.customTopics[existingIndex] = action.payload;
      } else {
        state.customTopics.push(action.payload);
      }
    });
    builder.addCase(joinCustomTopic.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });
    
    // Leave custom topic
    builder.addCase(leaveCustomTopic.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(leaveCustomTopic.fulfilled, (state, action) => {
      state.isLoading = false;
      const existingIndex = state.customTopics.findIndex(t => t.id === action.payload);
      if (existingIndex >= 0) {
        // Remove the topic from the list if we're leaving it
        state.customTopics.splice(existingIndex, 1);
      }
    });
    builder.addCase(leaveCustomTopic.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });
  },
});

export const { clearTopicsError } = topicsSlice.actions;
export default topicsSlice.reducer;
