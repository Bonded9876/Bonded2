import React, { useState, useEffect, useRef } from 'react';
import {
  StyleSheet,
  View,
  TouchableOpacity,
  Text,
  ActivityIndicator,
  Alert,
  Modal,
  Animated,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MapView, { Marker, PROVIDER_GOOGLE, Region } from 'react-native-maps';
import { Ionicons } from '@expo/vector-icons';
import { BottomTabNavigationProp } from '@react-navigation/bottom-tabs';
import { CompositeNavigationProp } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { MainTabParamList } from '../../navigation/MainNavigator';
import { MainStackParamList } from '../../navigation/MainNavigator';
import { ROUTES, DEFAULT_MAP_DELTA, MAX_NEARBY_DISTANCE_KM } from '../../constants';
import { useAuth } from '../../hooks/useAuth';
import { useLocation } from '../../hooks/useLocation';
import { useAppDispatch, useAppSelector } from '../../hooks/useRedux';
import { fetchUserTopics } from '../../store/slices/topicsSlice';
import Avatar from '../../components/shared/Avatar';
import Button from '../../components/shared/Button';
import EmptyState from '../../components/shared/EmptyState';
import LoadingScreen from '../shared/LoadingScreen';
import theme from '../../theme';
import { fetchNearbyUsers } from '../../api/userApi'; // You'll need to create this API

type MapScreenNavigationProp = CompositeNavigationProp<
  BottomTabNavigationProp<MainTabParamList, typeof ROUTES.MAP>,
  StackNavigationProp<MainStackParamList>
>;

interface MapScreenProps {
  navigation: MapScreenNavigationProp;
}

const MapScreen: React.FC<MapScreenProps> = ({ navigation }) => {
  const dispatch = useAppDispatch();
  const { user, hasPaid } = useAuth();
  const {
    currentLocation,
    isLoading: locationLoading,
    error: locationError,
    isPermissionGranted,
    isLocationSharingEnabled,
    refreshLocation,
    toggleLocationSharing,
  } = useLocation();
  
  const { userTopics } = useAppSelector(state => state.topics);
  
  const [nearbyUsers, setNearbyUsers] = useState<any[]>([]);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showUserProfile, setShowUserProfile] = useState(false);
  const [region, setRegion] = useState<Region | null>(null);
  const [distanceFilter, setDistanceFilter] = useState(2); // km
  const [showFilters, setShowFilters] = useState(false);
  
  const mapRef = useRef<MapView>(null);
  const profileAnimation = useRef(new Animated.Value(0)).current;

  // Load user topics when screen mounts
  useEffect(() => {
    if (user) {
      dispatch(fetchUserTopics(user.id));
    }
  }, [dispatch, user]);

  // Fetch nearby users when location or filters change
  useEffect(() => {
    const loadNearbyUsers = async () => {
      if (!currentLocation || !hasPaid) return;
      
      setIsLoading(true);
      try {
        const users = await fetchNearbyUsers({
          latitude: currentLocation.latitude,
          longitude: currentLocation.longitude,
          maxDistance: distanceFilter,
          topicIds: userTopics,
        });
        
        setNearbyUsers(users);
      } catch (error) {
        console.error('Error fetching nearby users:', error);
        Alert.alert('Error', 'Failed to fetch nearby users');
      } finally {
        setIsLoading(false);
      }
    };
    
    loadNearbyUsers();
  }, [currentLocation, distanceFilter, userTopics, hasPaid]);

  // Set initial region when location is available
  useEffect(() => {
    if (currentLocation) {
      const initialRegion = {
        latitude: currentLocation.latitude,
        longitude: currentLocation.longitude,
        latitudeDelta: DEFAULT_MAP_DELTA,
        longitudeDelta: DEFAULT_MAP_DELTA,
      };
      
      setRegion(initialRegion);
      
      // Center map on current location
      mapRef.current?.animateToRegion(initialRegion);
    }
  }, [currentLocation]);

  // Animate profile card in/out
  useEffect(() => {
    Animated.timing(profileAnimation, {
      toValue: showUserProfile ? 1 : 0,
      duration: 300,
      useNativeDriver: true,
    }).start();
  }, [showUserProfile, profileAnimation]);

  // Handle marker press
  const handleMarkerPress = (user: any) => {
    setSelectedUser(user);
    setShowUserProfile(true);
  };

  // Handle refresh button press
  const handleRefresh = () => {
    refreshLocation();
  };

  // Handle center button press
  const handleCenterMap = () => {
    if (currentLocation) {
      mapRef.current?.animateToRegion({
        latitude: currentLocation.latitude,
        longitude: currentLocation.longitude,
        latitudeDelta: DEFAULT_MAP_DELTA,
        longitudeDelta: DEFAULT_MAP_DELTA,
      });
    }
  };

  // Handle start chat
  const handleStartChat = () => {
    if (selectedUser) {
      setShowUserProfile(false);
      navigation.navigate(ROUTES.CHAT_DETAIL, { userId: selectedUser.id });
    }
  };

  // Handle view profile
  const handleViewProfile = () => {
    if (selectedUser) {
      setShowUserProfile(false);
      navigation.navigate(ROUTES.USER_PROFILE, { userId: selectedUser.id });
    }
  };

  // Check if payment is required
  const checkPaymentRequired = () => {
    if (!hasPaid) {
      Alert.alert(
        'Payment Required',
        'You need to complete your one-time payment to access this feature.',
        [
          {
            text: 'Pay Now',
            onPress: () => navigation.navigate(ROUTES.PAYMENT),
          },
          {
            text: 'Later',
            style: 'cancel',
          },
        ]
      );
      return true;
    }
    return false;
  };

  // Calculate translation for profile card
  const profileTranslateY = profileAnimation.interpolate({
    inputRange: [0, 1],
    outputRange: [300, 0],
  });

  // Show loading screen if location is still loading
  if (locationLoading) {
    return <LoadingScreen message="Getting your location..." />;
  }

  // Show permission error if location permission is not granted
  if (!isPermissionGranted) {
    return (
      <SafeAreaView style={styles.container}>
        <EmptyState
          title="Location Permission Required"
          message="Please enable location permissions in your device settings to use the map feature."
          icon="location"
          buttonTitle="Retry"
          onButtonPress={refreshLocation}
        />
      </SafeAreaView>
    );
  }

  // Show error message if there's a location error
  if (locationError) {
    return (
      <SafeAreaView style={styles.container}>
        <EmptyState
          title="Location Error"
          message={locationError}
          icon="alert-circle"
          buttonTitle="Retry"
          onButtonPress={refreshLocation}
        />
      </SafeAreaView>
    );
  }

  // Show payment required message if user hasn't paid
  if (!hasPaid) {
    return (
      <SafeAreaView style={styles.container}>
        <EmptyState
          title="Payment Required"
          message="Complete your one-time payment to access the map and see nearby users."
          icon="lock-closed"
          buttonTitle="Pay Now"
          onButtonPress={() => navigation.navigate(ROUTES.PAYMENT)}
        />
      </SafeAreaView>
    );
  }

  // Show message if location sharing is disabled
  if (!isLocationSharingEnabled) {
    return (
      <SafeAreaView style={styles.container}>
        <EmptyState
          title="Location Sharing Disabled"
          message="You need to enable location sharing to see nearby users."
          icon="eye-off"
          buttonTitle="Enable Sharing"
          onButtonPress={() => toggleLocationSharing(true)}
        />
      </SafeAreaView>
    );
  }

  return (
    <View style={styles.container}>
      {/* Map */}
      {currentLocation && (
        <MapView
          ref={mapRef}
          style={styles.map}
          provider={PROVIDER_GOOGLE}
          initialRegion={region || undefined}
          showsUserLocation
          showsMyLocationButton={false}
          showsCompass
          showsScale
          rotateEnabled={false}
        >
          {/* Nearby users markers */}
          {nearbyUsers.map((user) => (
            <Marker
              key={user.id}
              coordinate={{
                latitude: user.location.latitude,
                longitude: user.location.longitude,
              }}
              onPress={() => handleMarkerPress(user)}
            >
              <View style={styles.markerContainer}>
                <Avatar
                  uri={user.profileImage}
                  initials={user.displayName}
                  size="s"
                  status={user.online ? 'online' : 'offline'}
                  backgroundColor={
                    user.topicColor || theme.colors.primary[600]
                  }
                />
              </View>
            </Marker>
          ))}
        </MapView>
      )}

      {/* Header with stats */}
      <SafeAreaView edges={['top']} style={styles.header}>
        <View style={styles.headerContent}>
          <View style={styles.statsContainer}>
            <View style={styles.statBadge}>
              <Ionicons name="people" size={16} color={theme.colors.white} />
              <Text style={styles.statText}>{nearbyUsers.length} nearby</Text>
            </View>
            
            <View style={styles.statBadge}>
              <Ionicons name="locate" size={16} color={theme.colors.white} />
              <Text style={styles.statText}>{distanceFilter} km</Text>
            </View>
          </View>
          
          <TouchableOpacity
            style={styles.filterButton}
            onPress={() => setShowFilters(true)}
          >
            <Ionicons name="filter" size={24} color={theme.colors.white} />
          </TouchableOpacity>
        </View>
      </SafeAreaView>

      {/* Action buttons */}
      <View style={styles.actionButtonsContainer}>
        <TouchableOpacity
          style={styles.actionButton}
          onPress={handleRefresh}
          disabled={isLoading}
        >
          {isLoading ? (
            <ActivityIndicator size="small" color="#fff" />
          ) : (
            <Ionicons name="refresh" size={24} color="#fff" />
          )}
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.actionButton}
          onPress={handleCenterMap}
        >
          <Ionicons name="locate" size={24} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* User profile card */}
      {selectedUser && (
        <Animated.View
          style={[
            styles.profileCard,
            { transform: [{ translateY: profileTranslateY }] },
          ]}
        >
          <View style={styles.profileHeader}>
            <Avatar
              uri={selectedUser.profileImage}
              initials={selectedUser.displayName}
              size="l"
              status={selectedUser.online ? 'online' : 'offline'}
            />
            
            <View style={styles.profileInfo}>
              <Text style={styles.profileName}>{selectedUser.displayName}</Text>
              <Text style={styles.profileDistance}>
                {selectedUser.distance.toFixed(1)} km away
              </Text>
            </View>
            
            <TouchableOpacity
              style={styles.closeButton}
              onPress={() => setShowUserProfile(false)}
            >
              <Ionicons name="close" size={24} color={theme.colors.gray[500]} />
            </TouchableOpacity>
          </View>
          
          {selectedUser.bio && (
            <Text style={styles.profileBio}>{selectedUser.bio}</Text>
          )}
          
          <View style={styles.profileTopics}>
            {selectedUser.topics?.map((topic: any) => (
              <View
                key={topic.id}
                style={[
                  styles.topicBadge,
                  { backgroundColor: topic.color + '20' }, // Add transparency
                ]}
              >
                <Text
                  style={[styles.topicText, { color: topic.color }]}
                >
                  {topic.name}
                </Text>
              </View>
            ))}
          </View>
          
          <View style={styles.profileActions}>
            <Button
              title="Message"
              onPress={handleStartChat}
              leftIcon="chatbubble"
              style={styles.messageButton}
            />
            
            <Button
              title="View Profile"
              onPress={handleViewProfile}
              variant="outline"
            />
          </View>
        </Animated.View>
      )}

      {/* Filters modal */}
      <Modal
        visible={showFilters}
        transparent
        animationType="slide"
        onRequestClose={() => setShowFilters(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Map Filters</Text>
              <TouchableOpacity
                onPress={() => setShowFilters(false)}
              >
                <Ionicons name="close" size={24} color={theme.colors.gray[500]} />
              </TouchableOpacity>
            </View>
            
            <View style={styles.filterItem}>
              <Text style={styles.filterLabel}>
                Distance: {distanceFilter} km
              </Text>
              <View style={styles.sliderContainer}>
                <Text style={styles.sliderValue}>1</Text>
                <Slider
                  value={distanceFilter}
                  minimumValue={1}
                  maximumValue={MAX_NEARBY_DISTANCE_KM}
                  step={1}
                  onValueChange={setDistanceFilter}
                  minimumTrackTintColor={theme.colors.primary[600]}
                  maximumTrackTintColor={theme.colors.gray[300]}
                  thumbTintColor={theme.colors.primary[600]}
                  style={styles.slider}
                />
                <Text style={styles.sliderValue}>{MAX_NEARBY_DISTANCE_KM}</Text>
              </View>
            </View>
            
            <View style={styles.filterItem}>
              <Text style={styles.filterLabel}>Location Sharing</Text>
              <Switch
                value={isLocationSharingEnabled}
                onValueChange={toggleLocationSharing}
                trackColor={{
                  false: theme.colors.gray[300],
                  true: theme.colors.primary[600],
                }}
                thumbColor={theme.colors.white}
              />
            </View>
            
            <Button
              title="Apply Filters"
              onPress={() => setShowFilters(false)}
              fullWidth
              style={styles.applyButton}
            />
          </View>
        </View>
      </Modal>
    </View>
  );
};

// Import these components that we referenced but haven't created yet
import Slider from '@react-native-community/slider';
import { Switch } from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.white,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    backgroundColor: 'transparent',
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    margin: theme.spacing.m,
  },
  statsContainer: {
    flexDirection: 'row',
  },
  statBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    borderRadius: theme.borders.radius.l,
    paddingVertical: theme.spacing.xs,
    paddingHorizontal: theme.spacing.m,
    marginRight: theme.spacing.s,
  },
  statText: {
    color: theme.colors.white,
    fontSize: theme.typography.fontSize.s,
    fontWeight: '500',
    marginLeft: theme.spacing.xs,
  },
  filterButton: {
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    borderRadius: theme.borders.radius.circle,
    padding: theme.spacing.s,
  },
  actionButtonsContainer: {
    position: 'absolute',
    right: theme.spacing.m,
    bottom: 120,
  },
  actionButton: {
    backgroundColor: theme.colors.primary[600],
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: theme.spacing.s,
    ...theme.shadows.m,
  },
  markerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  profileCard: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: theme.colors.white,
    borderTopLeftRadius: theme.borders.radius.l,
    borderTopRightRadius: theme.borders.radius.l,
    padding: theme.spacing.l,
    ...theme.shadows.l,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: theme.spacing.m,
  },
  profileInfo: {
    flex: 1,
    marginLeft: theme.spacing.m,
  },
  profileName: {
    fontSize: theme.typography.fontSize.l,
    fontWeight: 'bold',
    color: theme.colors.gray[900],
  },
  profileDistance: {
    fontSize: theme.typography.fontSize.s,
    color: theme.colors.gray[600],
  },
  closeButton: {
    padding: theme.spacing.s,
  },
  profileBio: {
    fontSize: theme.typography.fontSize.m,
    color: theme.colors.gray[800],
    marginBottom: theme.spacing.m,
  },
  profileTopics: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: theme.spacing.m,
  },
  topicBadge: {
    borderRadius: theme.borders.radius.l,
    paddingVertical: theme.spacing.xs,
    paddingHorizontal: theme.spacing.m,
    marginRight: theme.spacing.s,
    marginBottom: theme.spacing.s,
  },
  topicText: {
    fontSize: theme.typography.fontSize.s,
    fontWeight: '500',
  },
  profileActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  messageButton: {
    flex: 1,
    marginRight: theme.spacing.m,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: theme.colors.white,
    borderTopLeftRadius: theme.borders.radius.l,
    borderTopRightRadius: theme.borders.radius.l,
    padding: theme.spacing.l,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing.l,
  },
  modalTitle: {
    fontSize: theme.typography.fontSize.l,
    fontWeight: 'bold',
    color: theme.colors.gray[900],
  },
  filterItem: {
    marginBottom: theme.spacing.l,
  },
  filterLabel: {
    fontSize: theme.typography.fontSize.m,
    fontWeight: '500',
    color: theme.colors.gray[800],
    marginBottom: theme.spacing.s,
  },
  sliderContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  slider: {
    flex: 1,
    height: 40,
  },
  sliderValue: {
    fontSize: theme.typography.fontSize.s,
    color: theme.colors.gray[600],
    width: 24,
    textAlign: 'center',
  },
  applyButton: {
    marginTop: theme.spacing.m,
  },
});

export default MapScreen;
