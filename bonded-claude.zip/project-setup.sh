#!/bin/bash

# Create project using Expo with TypeScript template
npx create-expo-app -t expo-template-blank-typescript bonded-app

cd bonded-app

# Install essential dependencies
npm install @react-navigation/native @react-navigation/stack @react-navigation/bottom-tabs
npm install react-native-gesture-handler react-native-reanimated react-native-screens
npm install react-native-safe-area-context @react-native-community/masked-view
npm install expo-location expo-image-picker expo-linear-gradient
npm install firebase @react-native-firebase/app @react-native-firebase/auth @react-native-firebase/firestore
npm install react-native-maps
npm install @reduxjs/toolkit react-redux
npm install date-fns
npm install react-native-vector-icons
npm install @react-native-community/slider

# Create project structure
mkdir -p src/{api,assets,components,constants,contexts,hooks,navigation,screens,services,store,theme,utils,types}
mkdir -p src/screens/{auth,main}
mkdir -p src/components/{shared,map,topic,profile,chat}

# Set up TypeScript properly
echo '{
  "extends": "expo/tsconfig.base",
  "compilerOptions": {
    "strict": true,
    "baseUrl": ".",
    "paths": {
      "@/*": ["src/*"]
    }
  }
}' > tsconfig.json

# Create essential files
touch src/constants/index.ts
touch src/theme/index.ts
touch src/store/index.ts
touch src/navigation/index.ts

echo "Project structure has been set up successfully!"
