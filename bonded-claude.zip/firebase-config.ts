import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  initializeAuth,
  getReactNativePersistence 
} from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { FIREBASE_CONFIG } from '../constants';

// Initialize Firebase
let app;
if (getApps().length === 0) {
  app = initializeApp(FIREBASE_CONFIG);
  
  // Initialize Auth with AsyncStorage persistence
  initializeAuth(app, {
    persistence: getReactNativePersistence(AsyncStorage)
  });
} else {
  app = getApp();
}

// Get Firebase services
const auth = getAuth(app);
const firestore = getFirestore(app);
const storage = getStorage(app);

export { auth, firestore, storage };

// Helper function to convert Firestore data to our app data models
export const firestoreConverter = <T>() => ({
  toFirestore: (data: T) => data,
  fromFirestore: (snapshot: any, options: any) => {
    const data = snapshot.data(options);
    return {
      id: snapshot.id,
      ...data,
    } as T;
  }
});
