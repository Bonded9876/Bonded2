import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { StackNavigationProp } from '@react-navigation/stack';
import { RouteProp } from '@react-navigation/native';
import { MainStackParamList } from '../../navigation/MainNavigator';
import { ROUTES } from '../../constants';
import { useAuth } from '../../hooks/useAuth';
import { useAppDispatch, useAppSelector } from '../../hooks/useRedux';
import { fetchUserTopics } from '../../store/slices/topicsSlice';
import { createOrGetChat } from '../../store/slices/chatsSlice';
import Avatar from '../../components/shared/Avatar';
import Button from '../../components/shared/Button';
import Header from '../../components/shared/Header';
import LoadingScreen from '../shared/LoadingScreen';
import theme from '../../theme';
import { fetchUserById } from '../../api/userApi'; // You'll need to implement this

type UserProfileScreenNavigationProp = StackNavigationProp<
  MainStackParamList,
  typeof ROUTES.USER_PROFILE
>;

type UserProfileScreenRouteProp = RouteProp<
  MainStackParamList,
  typeof ROUTES.USER_PROFILE
>;

interface UserProfileScreenProps {
  navigation: UserProfileScreenNavigationProp;
  route: UserProfileScreenRouteProp;
}

const UserProfileScreen: React.FC<UserProfileScreenProps> = ({
  navigation,
  route,
}) => {
  const { userId } = route.params;
  
  const dispatch = useAppDispatch();
  const { user } = useAuth();
  const { defaultTopics } = useAppSelector((state) => state.topics);
  
  const [profileUser, setProfileUser] = useState<any>(null);
  const [userTopics, setUserTopics] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isChatLoading, setIsChatLoading] = useState(false);
  const [commonTopics, setCommonTopics] = useState<any[]>([]);

  // Fetch user data and topics
  useEffect(() => {
    const loadUserData = async () => {
      try {
        // Fetch user data
        // In a real app, this would be an API call
        // const userData = await fetchUserById(userId);
        
        // For now, we'll use placeholder data
        const userData = {
          id: userId,
          displayName: 'User ' + userId.substring(0, 5),
          bio: 'This is a sample bio for the user profile. In a real app, this would contain the user\'s actual bio information.',
          profileImage: null,
          online: Math.random() > 0.5,
          distance: (Math.random() * 5).toFixed(1),
          topics: ['creative', 'active', 'knowledge'], // Sample topic IDs
          lastActive: new Date(),
        };
        
        setProfileUser(userData);
        setUserTopics(userData.topics || []);
        
        // Calculate common topics if the current user is logged in
        if (user) {
          // This would be from your Redux state in a real app
          const currentUserTopics = user.topics || [];
          
          // Find common topics
          const common = userData.topics.filter((topicId: string) => 
            currentUserTopics.includes(topicId)
          );
          
          // Get topic details
          const commonTopicDetails = defaultTopics.filter((topic) => 
            common.includes(topic.id)
          );
          
          setCommonTopics(commonTopicDetails);
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
        Alert.alert('Error', 'Failed to load user profile');
      } finally {
        setIsLoading(false);
      }
    };
    
    loadUserData();
  }, [userId, user, defaultTopics]);

  // Get topic objects from IDs
  const userTopicDetails = defaultTopics.filter((topic) => 
    userTopics.includes(topic.id)
  );

  // Handle starting a chat
  const handleStartChat = async () => {
    if (!user || !profileUser) return;
    
    setIsChatLoading(true);
    try {
      // Create or get a chat with this user
      const result = await dispatch(createOrGetChat({
        currentUserId: user.id,
        otherUserId: profileUser.id,
      })).unwrap();
      
      // Navigate to the chat screen
      navigation.navigate(ROUTES.CHAT_DETAIL, {
        chatId: result.id,
        userId: profileUser.id,
      });
    } catch (error) {
      console.error('Error creating chat:', error);
      Alert.alert('Error', 'Failed to start chat. Please try again.');
    } finally {
      setIsChatLoading(false);
    }
  };

  // Loading state
  if (isLoading) {
    return <LoadingScreen message="Loading profile..." />;
  }

  // If user not found
  if (!profileUser) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <Header
          title="User Profile"
          showBackButton
          onBackPress={() => navigation.goBack()}
        />
        <View style={styles.errorContainer}>
          <Ionicons name="alert-circle" size={64} color={theme.colors.gray[400]} />
          <Text style={styles.errorText}>User not found</Text>
          <Button
            title="Go Back"
            onPress={() => navigation.goBack()}
            style={styles.errorButton}
          />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <Header
        title="User Profile"
        showBackButton
        onBackPress={() => navigation.goBack()}
      />
      
      <ScrollView>
        {/* Profile Header */}
        <View style={styles.profileHeader}>
          <Avatar
            uri={profileUser.profileImage}
            initials={profileUser.displayName}
            size="xl"
            status={profileUser.online ? 'online' : 'offline'}
            backgroundColor={theme.colors.primary[600]}
          />
          
          <Text style={styles.userName}>{profileUser.displayName}</Text>
          
          <View style={styles.userInfo}>
            <View style={styles.infoItem}>
              <Ionicons name="location" size={16} color={theme.colors.gray[500]} />
              <Text style={styles.infoText}>{profileUser.distance} km away</Text>
            </View>
            
            <View style={styles.infoSeparator} />
            
            <View style={styles.infoItem}>
              <Ionicons name="time" size={16} color={theme.colors.gray[500]} />
              <Text style={styles.infoText}>
                {profileUser.online ? 'Online now' : 'Last active recently'}
              </Text>
            </View>
          </View>
          
          {/* Action Buttons */}
          <View style={styles.actionButtons}>
            <Button
              title="Message"
              leftIcon="chatbubble"
              onPress={handleStartChat}
              loading={isChatLoading}
              disabled={isChatLoading}
              style={styles.actionButton}
            />
          </View>
        </View>
        
        {/* Common Topics Section (if any) */}
        {commonTopics.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Common Interests</Text>
            <View style={styles.topicsContainer}>
              {commonTopics.map((topic) => (
                <View
                  key={topic.id}
                  style={[
                    styles.topicChip,
                    { backgroundColor: `${topic.color}20` }, // Add transparency
                  ]}
                >
                  <Ionicons
                    name={(topic.icon as keyof typeof Ionicons.glyphMap) || 'people'}
                    size={16}
                    color={topic.color}
                    style={styles.topicIcon}
                  />
                  <Text
                    style={[styles.topicName, { color: topic.color }]}
                  >
                    {topic.name}
                  </Text>
                </View>
              ))}
            </View>
          </View>
        )}
        
        {/* Bio Section */}
        {profileUser.bio && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>About</Text>
            <Text style={styles.bioText}>{profileUser.bio}</Text>
          </View>
        )}
        
        {/* Topics Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Interests</Text>
          
          {userTopicDetails.length === 0 ? (
            <Text style={styles.emptyText}>No interests shared</Text>
          ) : (
            <View style={styles.topicsContainer}>
              {userTopicDetails.map((topic) => (
                <View
                  key={topic.id}
                  style={styles.topicChip}
                >
                  <Ionicons
                    name={(topic.icon as keyof typeof Ionicons.glyphMap) || 'people'}
                    size={16}
                    color={theme.colors.gray[600]}
                    style={styles.topicIcon}
                  />
                  <Text style={styles.topicName}>{topic.name}</Text>
                </View>
              ))}
            </View>
          )}
        </View>
        
        {/* Report Section */}
        <TouchableOpacity
          style={styles.reportButton}
          onPress={() => {
            Alert.alert(
              'Report User',
              'Are you sure you want to report this user?',
              [
                {
                  text: 'Cancel',
                  style: 'cancel',
                },
                {
                  text: 'Report',
                  style: 'destructive',
                  onPress: () => {
                    // Report user logic here
                    Alert.alert(
                      'User Reported',
                      'Thank you for your report. We will review it shortly.'
                    );
                  },
                },
              ]
            );
          }}
        >
          <Ionicons name="flag" size={20} color={theme.colors.error.main} />
          <Text style={styles.reportText}>Report this user</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.white,
  },
  profileHeader: {
    alignItems: 'center',
    padding: theme.spacing.l,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.gray[200],
  },
  userName: {
    fontSize: theme.typography.fontSize.xl,
    fontWeight: 'bold',
    color: theme.colors.gray[900],
    marginTop: theme.spacing.m,
    marginBottom: theme.spacing.s,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: theme.spacing.l,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  infoText: {
    fontSize: theme.typography.fontSize.s,
    color: theme.colors.gray[600],
    marginLeft: theme.spacing.xs,
  },
  infoSeparator: {
    width: 4,
    height: 4,
    borderRadius: 2,
    backgroundColor: theme.colors.gray[400],
    marginHorizontal: theme.spacing.s,
  },
  actionButtons: {
    flexDirection: 'row',
  },
  actionButton: {
    minWidth: 150,
  },
  section: {
    padding: theme.spacing.l,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.gray[200],
  },
  sectionTitle: {
    fontSize: theme.typography.fontSize.l,
    fontWeight: 'bold',
    color: theme.colors.gray[900],
    marginBottom: theme.spacing.m,
  },
  bioText: {
    fontSize: theme.typography.fontSize.m,
    color: theme.colors.gray[800],
    lineHeight: 22,
  },
  topicsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  topicChip: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.gray[100],
    paddingVertical: theme.spacing.xs,
    paddingHorizontal: theme.spacing.m,
    borderRadius: theme.borders.radius.l,
    marginRight: theme.spacing.s,
    marginBottom: theme.spacing.s,
  },
  topicIcon: {
    marginRight: theme.spacing.xs,
  },
  topicName: {
    fontSize: theme.typography.fontSize.s,
    color: theme.colors.gray[800],
  },
  emptyText: {
    fontSize: theme.typography.fontSize.m,
    color: theme.colors.gray[500],
    fontStyle: 'italic',
  },
  reportButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: theme.spacing.l,
  },
  reportText: {
    fontSize: theme.typography.fontSize.s,
    color: theme.colors.error.main,
    marginLeft: theme.spacing.s,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: theme.spacing.l,
  },
  errorText: {
    fontSize: theme.typography.fontSize.l,
    color: theme.colors.gray[800],
    marginTop: theme.spacing.m,
    marginBottom: theme.spacing.l,
  },
  errorButton: {
    minWidth: 150,
  },
});

export default UserProfileScreen;
