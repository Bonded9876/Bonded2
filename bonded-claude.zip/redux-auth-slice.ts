import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword,
  signOut,
  updateProfile,
  User as FirebaseUser
} from 'firebase/auth';
import { 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc,
  serverTimestamp
} from 'firebase/firestore';
import { auth, firestore } from '../../services/firebase';
import { User, AuthState } from '../../types';

// Initial state
const initialState: AuthState = {
  user: null,
  isLoading: false,
  error: null,
};

// Register a new user
export const registerUser = createAsyncThunk(
  'auth/register',
  async ({ email, password, displayName }: { email: string; password: string; displayName: string }, { rejectWithValue }) => {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const firebaseUser = userCredential.user;
      
      // Update Firebase Auth profile
      await updateProfile(firebaseUser, { displayName });
      
      // Create user document in Firestore
      const userData: Omit<User, 'id'> = {
        email,
        displayName,
        createdAt: new Date(),
        hasPaid: false,
        topics: [],
        bio: '',
      };
      
      await setDoc(doc(firestore, 'users', firebaseUser.uid), {
        ...userData,
        createdAt: serverTimestamp(),
      });
      
      return {
        id: firebaseUser.uid,
        ...userData,
      } as User;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Sign in user
export const signInUser = createAsyncThunk(
  'auth/signIn',
  async ({ email, password }: { email: string; password: string }, { rejectWithValue }) => {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const firebaseUser = userCredential.user;
      
      // Get user data from Firestore
      const userDoc = await getDoc(doc(firestore, 'users', firebaseUser.uid));
      
      if (!userDoc.exists()) {
        throw new Error('User data not found');
      }
      
      const userData = userDoc.data() as Omit<User, 'id'>;
      
      return {
        id: firebaseUser.uid,
        ...userData,
        createdAt: userData.createdAt instanceof Date 
          ? userData.createdAt 
          : new Date(userData.createdAt.seconds * 1000),
      } as User;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Sign out user
export const signOutUser = createAsyncThunk(
  'auth/signOut',
  async (_, { rejectWithValue }) => {
    try {
      await signOut(auth);
      return null;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Update user profile
export const updateUserProfile = createAsyncThunk(
  'auth/updateProfile',
  async ({ userId, data }: { userId: string; data: Partial<User> }, { rejectWithValue }) => {
    try {
      const userRef = doc(firestore, 'users', userId);
      
      await updateDoc(userRef, {
        ...data,
        updatedAt: serverTimestamp(),
      });
      
      // Get updated user data
      const userDoc = await getDoc(userRef);
      
      if (!userDoc.exists()) {
        throw new Error('User data not found');
      }
      
      const userData = userDoc.data() as Omit<User, 'id'>;
      
      return {
        id: userId,
        ...userData,
        createdAt: userData.createdAt instanceof Date 
          ? userData.createdAt 
          : new Date(userData.createdAt.seconds * 1000),
      } as User;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Complete payment
export const completePayment = createAsyncThunk(
  'auth/completePayment',
  async (userId: string, { rejectWithValue }) => {
    try {
      const userRef = doc(firestore, 'users', userId);
      
      await updateDoc(userRef, {
        hasPaid: true,
        paymentDate: serverTimestamp(),
      });
      
      return { hasPaid: true };
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Auth slice
const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    updateUser: (state, action: PayloadAction<User | null>) => {
      state.user = action.payload;
    },
    clearError: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    // Register
    builder.addCase(registerUser.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(registerUser.fulfilled, (state, action) => {
      state.isLoading = false;
      state.user = action.payload;
    });
    builder.addCase(registerUser.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });
    
    // Sign in
    builder.addCase(signInUser.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(signInUser.fulfilled, (state, action) => {
      state.isLoading = false;
      state.user = action.payload;
    });
    builder.addCase(signInUser.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });
    
    // Sign out
    builder.addCase(signOutUser.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(signOutUser.fulfilled, (state) => {
      state.isLoading = false;
      state.user = null;
    });
    builder.addCase(signOutUser.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });
    
    // Update profile
    builder.addCase(updateUserProfile.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(updateUserProfile.fulfilled, (state, action) => {
      state.isLoading = false;
      state.user = action.payload;
    });
    builder.addCase(updateUserProfile.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });
    
    // Complete payment
    builder.addCase(completePayment.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(completePayment.fulfilled, (state) => {
      state.isLoading = false;
      if (state.user) {
        state.user.hasPaid = true;
      }
    });
    builder.addCase(completePayment.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });
  },
});

export const { updateUser, clearError } = authSlice.actions;
export default authSlice.reducer;
