import React from 'react';
import {
  StyleSheet,
  View,
  Image,
  Text,
  StyleProp,
  ViewStyle,
  TextStyle,
  ImageStyle,
  TouchableOpacity,
} from 'react-native';
import theme from '../../theme';

type AvatarSize = 'xs' | 's' | 'm' | 'l' | 'xl';
type AvatarStatus = 'online' | 'offline' | 'away' | 'busy' | 'none';

interface AvatarProps {
  uri?: string | null;
  initials?: string;
  size?: AvatarSize;
  status?: AvatarStatus;
  style?: StyleProp<ViewStyle>;
  imageStyle?: StyleProp<ImageStyle>;
  textStyle?: StyleProp<TextStyle>;
  onPress?: () => void;
  backgroundColor?: string;
  textColor?: string;
}

const Avatar: React.FC<AvatarProps> = ({
  uri,
  initials,
  size = 'm',
  status = 'none',
  style,
  imageStyle,
  textStyle,
  onPress,
  backgroundColor = theme.colors.primary[600],
  textColor = theme.colors.white,
}) => {
  // Get avatar size
  const getSize = () => {
    switch (size) {
      case 'xs':
        return 24;
      case 's':
        return 32;
      case 'm':
        return 48;
      case 'l':
        return 64;
      case 'xl':
        return 96;
      default:
        return 48;
    }
  };

  // Get status size and color
  const getStatusSize = () => {
    switch (size) {
      case 'xs':
        return 6;
      case 's':
        return 8;
      case 'm':
        return 12;
      case 'l':
        return 14;
      case 'xl':
        return 16;
      default:
        return 12;
    }
  };

  const getStatusColor = () => {
    switch (status) {
      case 'online':
        return theme.colors.success.main;
      case 'offline':
        return theme.colors.gray[400];
      case 'away':
        return theme.colors.warning.main;
      case 'busy':
        return theme.colors.error.main;
      default:
        return 'transparent';
    }
  };

  // Get font size for initials
  const getFontSize = () => {
    switch (size) {
      case 'xs':
        return theme.typography.fontSize.xs;
      case 's':
        return theme.typography.fontSize.s;
      case 'm':
        return theme.typography.fontSize.m;
      case 'l':
        return theme.typography.fontSize.l;
      case 'xl':
        return theme.typography.fontSize.xxl;
      default:
        return theme.typography.fontSize.m;
    }
  };

  // Get initial text (first letter of initials or placeholder)
  const getInitialText = () => {
    if (initials && initials.length > 0) {
      return initials.charAt(0).toUpperCase();
    }
    return '?';
  };

  const avatarSize = getSize();
  const avatarStyles = [
    styles.container,
    {
      width: avatarSize,
      height: avatarSize,
      borderRadius: avatarSize / 2,
    },
    style,
  ];

  const avatarContent = uri ? (
    <Image
      source={{ uri }}
      style={[
        styles.image,
        {
          width: avatarSize,
          height: avatarSize,
          borderRadius: avatarSize / 2,
        },
        imageStyle,
      ]}
    />
  ) : (
    <View
      style={[
        styles.initialsContainer,
        {
          width: avatarSize,
          height: avatarSize,
          borderRadius: avatarSize / 2,
          backgroundColor,
        },
      ]}
    >
      <Text
        style={[
          styles.initialsText,
          {
            fontSize: getFontSize(),
            color: textColor,
          },
          textStyle,
        ]}
      >
        {getInitialText()}
      </Text>
    </View>
  );

  const statusIndicator =
    status !== 'none' ? (
      <View
        style={[
          styles.statusDot,
          {
            width: getStatusSize(),
            height: getStatusSize(),
            borderRadius: getStatusSize() / 2,
            backgroundColor: getStatusColor(),
          },
        ]}
      />
    ) : null;

  if (onPress) {
    return (
      <TouchableOpacity
        style={styles.wrapper}
        onPress={onPress}
        activeOpacity={0.8}
      >
        <View style={avatarStyles}>{avatarContent}</View>
        {statusIndicator}
      </TouchableOpacity>
    );
  }

  return (
    <View style={styles.wrapper}>
      <View style={avatarStyles}>{avatarContent}</View>
      {statusIndicator}
    </View>
  );
};

const styles = StyleSheet.create({
  wrapper: {
    position: 'relative',
  },
  container: {
    overflow: 'hidden',
  },
  image: {
    resizeMode: 'cover',
  },
  initialsContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  initialsText: {
    fontWeight: 'bold',
  },
  statusDot: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    borderWidth: 2,
    borderColor: theme.colors.white,
  },
});

export default Avatar;
