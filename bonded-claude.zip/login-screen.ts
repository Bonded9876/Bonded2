import React, { useState } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StackNavigationProp } from '@react-navigation/stack';
import { AuthStackParamList } from '../../navigation/AuthNavigator';
import { ROUTES } from '../../constants';
import Button from '../../components/shared/Button';
import Input from '../../components/shared/Input';
import theme from '../../theme';
import { useAppDispatch, useAppSelector } from '../../hooks/useRedux';
import { signInUser, clearError } from '../../store/slices/authSlice';

type LoginScreenNavigationProp = StackNavigationProp<
  AuthStackParamList,
  typeof ROUTES.LOGIN
>;

interface LoginScreenProps {
  navigation: LoginScreenNavigationProp;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ navigation }) => {
  const dispatch = useAppDispatch();
  const { isLoading, error } = useAppSelector((state) => state.auth);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');

  // Clear any existing auth errors when component mounts
  React.useEffect(() => {
    dispatch(clearError());
  }, [dispatch]);

  // Validate form
  const validateForm = () => {
    let isValid = true;

    // Email validation
    if (!email.trim()) {
      setEmailError('Email is required');
      isValid = false;
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      setEmailError('Email is invalid');
      isValid = false;
    } else {
      setEmailError('');
    }

    // Password validation
    if (!password) {
      setPasswordError('Password is required');
      isValid = false;
    } else if (password.length < 6) {
      setPasswordError('Password must be at least 6 characters');
      isValid = false;
    } else {
      setPasswordError('');
    }

    return isValid;
  };

  // Handle login
  const handleLogin = async () => {
    if (!validateForm()) return;

    const result = await dispatch(signInUser({ email, password }));
    
    if (signInUser.rejected.match(result)) {
      // Handle specific errors if needed
      console.log('Login failed:', result.payload);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 64 : 0}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContainer}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.header}>
            <Text style={styles.title}>Welcome Back</Text>
            <Text style={styles.subtitle}>
              Sign in to continue connecting with the Bonded community
            </Text>
          </View>

          <View style={styles.form}>
            <Input
              label="Email"
              placeholder="Enter your email"
              keyboardType="email-address"
              autoCapitalize="none"
              autoComplete="email"
              value={email}
              onChangeText={(text) => {
                setEmail(text);
                setEmailError('');
              }}
              error={emailError}
              leftIcon="mail-outline"
            />

            <Input
              label="Password"
              placeholder="Enter your password"
              secureTextEntry
              value={password}
              onChangeText={(text) => {
                setPassword(text);
                setPasswordError('');
              }}
              error={passwordError}
              leftIcon="lock-closed-outline"
            />

            {error && <Text style={styles.errorText}>{error}</Text>}

            <TouchableOpacity
              style={styles.forgotPasswordContainer}
              onPress={() => navigation.navigate(ROUTES.FORGOT_PASSWORD)}
            >
              <Text style={styles.forgotPasswordText}>Forgot Password?</Text>
            </TouchableOpacity>

            <Button
              title="Sign In"
              onPress={handleLogin}
              loading={isLoading}
              disabled={isLoading}
              fullWidth
              style={styles.loginButton}
            />

            <View style={styles.signupContainer}>
              <Text style={styles.signupText}>Don't have an account?</Text>
              <TouchableOpacity
                onPress={() => navigation.navigate(ROUTES.SIGNUP)}
              >
                <Text style={styles.signupLink}>Sign Up</Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: theme.colors.white,
  },
  container: {
    flex: 1,
  },
  scrollContainer: {
    flexGrow: 1,
    padding: theme.spacing.l,
  },
  header: {
    marginTop: theme.spacing.xl,
    marginBottom: theme.spacing.xl,
  },
  title: {
    fontSize: theme.typography.fontSize.xxxl,
    fontWeight: 'bold',
    color: theme.colors.gray[900],
    marginBottom: theme.spacing.s,
  },
  subtitle: {
    fontSize: theme.typography.fontSize.m,
    color: theme.colors.gray[600],
  },
  form: {
    flex: 1,
  },
  errorText: {
    color: theme.colors.error.main,
    fontSize: theme.typography.fontSize.s,
    marginTop: theme.spacing.s,
  },
  forgotPasswordContainer: {
    alignSelf: 'flex-end',
    marginTop: theme.spacing.s,
    marginBottom: theme.spacing.l,
  },
  forgotPasswordText: {
    color: theme.colors.primary[600],
    fontSize: theme.typography.fontSize.s,
  },
  loginButton: {
    marginBottom: theme.spacing.l,
  },
  signupContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: theme.spacing.l,
  },
  signupText: {
    color: theme.colors.gray[600],
    fontSize: theme.typography.fontSize.m,
    marginRight: theme.spacing.xs,
  },
  signupLink: {
    color: theme.colors.primary[600],
    fontSize: theme.typography.fontSize.m,
    fontWeight: 'bold',
  },
});

export default LoginScreen;
