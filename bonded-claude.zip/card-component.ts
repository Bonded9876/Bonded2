import React, { ReactNode } from 'react';
import {
  StyleSheet,
  View,
  StyleProp,
  ViewStyle,
  TouchableOpacity,
} from 'react-native';
import theme from '../../theme';

interface CardProps {
  children: ReactNode;
  style?: StyleProp<ViewStyle>;
  onPress?: () => void;
  disabled?: boolean;
  elevation?: 'none' | 'xs' | 's' | 'm' | 'l';
  rounded?: 'none' | 'xs' | 's' | 'm' | 'l' | 'xl' | 'full';
  padding?: 'none' | 'xs' | 's' | 'm' | 'l' | 'xl';
}

const Card: React.FC<CardProps> = ({
  children,
  style,
  onPress,
  disabled = false,
  elevation = 's',
  rounded = 'm',
  padding = 'm',
}) => {
  const cardStyles = [
    styles.card,
    styles[`elevation${elevation.charAt(0).toUpperCase() + elevation.slice(1)}`],
    styles[`rounded${rounded.charAt(0).toUpperCase() + rounded.slice(1)}`],
    styles[`padding${padding.charAt(0).toUpperCase() + padding.slice(1)}`],
    style,
  ];

  if (onPress) {
    return (
      <TouchableOpacity
        style={cardStyles}
        onPress={onPress}
        disabled={disabled}
        activeOpacity={0.8}
      >
        {children}
      </TouchableOpacity>
    );
  }

  return <View style={cardStyles}>{children}</View>;
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: theme.colors.white,
    overflow: 'hidden',
  },
  
  // Elevation styles
  elevationNone: {
    ...theme.shadows.none,
  },
  elevationXs: {
    ...theme.shadows.xs,
  },
  elevationS: {
    ...theme.shadows.s,
  },
  elevationM: {
    ...theme.shadows.m,
  },
  elevationL: {
    ...theme.shadows.l,
  },
  
  // Border radius styles
  roundedNone: {
    borderRadius: 0,
  },
  roundedXs: {
    borderRadius: theme.borders.radius.xs,
  },
  roundedS: {
    borderRadius: theme.borders.radius.s,
  },
  roundedM: {
    borderRadius: theme.borders.radius.m,
  },
  roundedL: {
    borderRadius: theme.borders.radius.l,
  },
  roundedXl: {
    borderRadius: theme.borders.radius.xl,
  },
  roundedFull: {
    borderRadius: theme.borders.radius.circle,
  },
  
  // Padding styles
  paddingNone: {
    padding: 0,
  },
  paddingXs: {
    padding: theme.spacing.xs,
  },
  paddingS: {
    padding: theme.spacing.s,
  },
  paddingM: {
    padding: theme.spacing.m,
  },
  paddingL: {
    padding: theme.spacing.l,
  },
  paddingXl: {
    padding: theme.spacing.xl,
  },
});

export default Card;
