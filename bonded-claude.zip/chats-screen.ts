import React, { useEffect, useState } from 'react';
import {
  StyleSheet,
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { format, isToday, isYesterday, formatDistanceToNow } from 'date-fns';
import { BottomTabNavigationProp } from '@react-navigation/bottom-tabs';
import { CompositeNavigationProp } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { MainTabParamList } from '../../navigation/MainNavigator';
import { MainStackParamList } from '../../navigation/MainNavigator';
import { ROUTES } from '../../constants';
import { useAuth } from '../../hooks/useAuth';
import { useAppDispatch, useAppSelector } from '../../hooks/useRedux';
import { fetchUserChats } from '../../store/slices/chatsSlice';
import { Chat } from '../../types';
import Header from '../../components/shared/Header';
import EmptyState from '../../components/shared/EmptyState';
import Avatar from '../../components/shared/Avatar';
import theme from '../../theme';

type ChatsScreenNavigationProp = CompositeNavigationProp<
  BottomTabNavigationProp<MainTabParamList, typeof ROUTES.CHATS>,
  StackNavigationProp<MainStackParamList>
>;

interface ChatsScreenProps {
  navigation: ChatsScreenNavigationProp;
}

// Helper function to format chat timestamp
const formatChatTime = (timestamp: Date | undefined) => {
  if (!timestamp) return '';
  
  if (isToday(timestamp)) {
    return format(timestamp, 'h:mm a');
  } else if (isYesterday(timestamp)) {
    return 'Yesterday';
  } else {
    return format(timestamp, 'MM/dd/yyyy');
  }
};

const ChatsScreen: React.FC<ChatsScreenProps> = ({ navigation }) => {
  const dispatch = useAppDispatch();
  const { user, hasPaid } = useAuth();
  const { chats, isLoading } = useAppSelector(state => state.chats);
  
  const [chatUsers, setChatUsers] = useState<Record<string, any>>({});

  // Load user chats when component mounts
  useEffect(() => {
    if (user && hasPaid) {
      dispatch(fetchUserChats(user.id));
    }
  }, [dispatch, user, hasPaid]);

  // Fetch other users' data for each chat
  useEffect(() => {
    const fetchChatUsers = async () => {
      if (!user) return;
      
      const usersData: Record<string, any> = {};
      
      // Ideally, we'd batch these requests or use a more efficient method
      for (const chat of chats) {
        const otherUserId = chat.participants.find(id => id !== user.id);
        
        if (otherUserId && !chatUsers[otherUserId]) {
          try {
            // This would be replaced with an actual API call to get user data
            // For now, we'll simulate it
            const userData = await fetch(`/api/users/${otherUserId}`).then(res => res.json());
            usersData[otherUserId] = userData;
          } catch (error) {
            console.error('Error fetching user data:', error);
          }
        }
      }
      
      setChatUsers(prevUsers => ({ ...prevUsers, ...usersData }));
    };
    
    fetchChatUsers();
  }, [chats, user]);

  // Navigate to chat detail
  const handleChatPress = (chat: Chat) => {
    if (user) {
      const otherUserId = chat.participants.find(id => id !== user.id);
      
      if (otherUserId) {
        navigation.navigate(ROUTES.CHAT_DETAIL, {
          chatId: chat.id,
          userId: otherUserId,
        });
      }
    }
  };

  // Render a chat item
  const renderChatItem = ({ item }: { item: Chat }) => {
    if (!user) return null;
    
    const otherUserId = item.participants.find(id => id !== user.id);
    if (!otherUserId) return null;
    
    // Use placeholder data until we have the real user data
    const otherUser = chatUsers[otherUserId] || {
      displayName: 'Loading...',
      profileImage: null,
      online: false,
    };
    
    return (
      <TouchableOpacity
        style={styles.chatItem}
        onPress={() => handleChatPress(item)}
      >
        <Avatar
          uri={otherUser.profileImage}
          initials={otherUser.displayName}
          size="m"
          status={otherUser.online ? 'online' : 'offline'}
        />
        
        <View style={styles.chatContent}>
          <View style={styles.chatHeader}>
            <Text style={styles.chatName} numberOfLines={1}>
              {otherUser.displayName}
            </Text>
            <Text style={styles.chatTime}>
              {formatChatTime(item.lastMessageTimestamp)}
            </Text>
          </View>
          
          <Text style={styles.chatMessage} numberOfLines={1}>
            {item.lastMessage || 'No messages yet'}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  // If the user hasn't completed payment
  if (!hasPaid) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <Header title="Messages" />
        <EmptyState
          title="Payment Required"
          message="Complete your one-time payment to access messaging features."
          icon="lock-closed"
          buttonTitle="Pay Now"
          onButtonPress={() => navigation.navigate(ROUTES.PAYMENT)}
        />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <Header title="Messages" />
      
      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={theme.colors.primary[600]} />
          <Text style={styles.loadingText}>Loading conversations...</Text>
        </View>
      ) : (
        <FlatList
          data={chats}
          renderItem={renderChatItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContainer}
          ListEmptyComponent={
            <EmptyState
              title="No Messages Yet"
              message="Start a conversation with someone from the map to connect in real life."
              icon="chatbubbles-outline"
            />
          }
        />
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.white,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: theme.spacing.l,
  },
  loadingText: {
    marginTop: theme.spacing.m,
    fontSize: theme.typography.fontSize.m,
    color: theme.colors.gray[600],
  },
  listContainer: {
    flexGrow: 1,
  },
  chatItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: theme.spacing.m,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.gray[200],
  },
  chatContent: {
    flex: 1,
    marginLeft: theme.spacing.m,
  },
  chatHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing.xs,
  },
  chatName: {
    fontSize: theme.typography.fontSize.m,
    fontWeight: 'bold',
    color: theme.colors.gray[900],
    flex: 1,
    marginRight: theme.spacing.s,
  },
  chatTime: {
    fontSize: theme.typography.fontSize.xs,
    color: theme.colors.gray[500],
  },
  chatMessage: {
    fontSize: theme.typography.fontSize.s,
    color: theme.colors.gray[600],
  },
});

export default ChatsScreen;
