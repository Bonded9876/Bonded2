import React, { useState, useEffect, useRef } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { format } from 'date-fns';
import { StackNavigationProp } from '@react-navigation/stack';
import { RouteProp } from '@react-navigation/native';
import { MainStackParamList } from '../../navigation/MainNavigator';
import { ROUTES, MESSAGE_EXPIRATION_HOURS } from '../../constants';
import { useAuth } from '../../hooks/useAuth';
import { useAppDispatch, useAppSelector } from '../../hooks/useRedux';
import {
  createOrGetChat,
  sendMessage,
  fetchMessages,
  markMessagesAsRead,
} from '../../store/slices/chatsSlice';
import { Message } from '../../types';
import Header from '../../components/shared/Header';
import Avatar from '../../components/shared/Avatar';
import EmptyState from '../../components/shared/EmptyState';
import LoadingScreen from '../shared/LoadingScreen';
import theme from '../../theme';

type ChatDetailScreenNavigationProp = StackNavigationProp<
  MainStackParamList,
  typeof ROUTES.CHAT_DETAIL
>;

type ChatDetailScreenRouteProp = RouteProp<
  MainStackParamList,
  typeof ROUTES.CHAT_DETAIL
>;

interface ChatDetailScreenProps {
  navigation: ChatDetailScreenNavigationProp;
  route: ChatDetailScreenRouteProp;
}

const ChatDetailScreen: React.FC<ChatDetailScreenProps> = ({
  navigation,
  route,
}) => {
  const { chatId: routeChatId, userId: otherUserId } = route.params;
  
  const dispatch = useAppDispatch();
  const { user } = useAuth();
  const { currentChat, messages, isLoading } = useAppSelector((state) => state.chats);
  
  const [inputText, setInputText] = useState('');
  const [otherUser, setOtherUser] = useState<any>(null);
  const [sending, setSending] = useState(false);
  
  const flatListRef = useRef<FlatList>(null);

  // Initialize chat or get existing chat
  useEffect(() => {
    const initializeChat = async () => {
      try {
        if (!user || !otherUserId) return;
        
        // If we don't have a chatId from the route, create/get a chat
        if (!routeChatId) {
          await dispatch(createOrGetChat({ 
            currentUserId: user.id, 
            otherUserId 
          })).unwrap();
        }
        
        // Fetch messages for the chat
        await dispatch(fetchMessages({ 
          chatId: routeChatId || currentChat?.id || '',
        })).unwrap();
        
        // Mark messages as read
        if (routeChatId || currentChat?.id) {
          dispatch(markMessagesAsRead({ 
            chatId: routeChatId || currentChat?.id || '', 
            userId: user.id 
          }));
        }
      } catch (error) {
        console.error('Error initializing chat:', error);
        Alert.alert(
          'Error',
          'Failed to load chat. Please try again.',
          [{ text: 'OK', onPress: () => navigation.goBack() }]
        );
      }
    };
    
    initializeChat();
  }, [dispatch, user, otherUserId, routeChatId, currentChat]);

  // Fetch other user's data
  useEffect(() => {
    const fetchOtherUserData = async () => {
      if (!otherUserId) return;
      
      try {
        // This would be replaced with an actual API call
        // For now, we'll simulate it with placeholder data
        // const userData = await fetch(`/api/users/${otherUserId}`).then(res => res.json());
        
        // Temporary placeholder data
        const userData = {
          id: otherUserId,
          displayName: 'User ' + otherUserId.substring(0, 5),
          profileImage: null,
          online: Math.random() > 0.5, // Random online status
        };
        
        setOtherUser(userData);
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };
    
    fetchOtherUserData();
  }, [otherUserId]);

  // Format message timestamp
  const formatMessageTime = (timestamp: Date) => {
    return format(timestamp, 'h:mm a');
  };

  // Calculate expiration time for a message
  const calculateExpirationTime = (timestamp: Date) => {
    const expirationTime = new Date(timestamp);
    expirationTime.setHours(expirationTime.getHours() + MESSAGE_EXPIRATION_HOURS);
    
    const now = new Date();
    const hoursLeft = Math.max(0, (expirationTime.getTime() - now.getTime()) / (60 * 60 * 1000));
    
    return Math.round(hoursLeft);
  };

  // Send a message
  const handleSendMessage = async () => {
    if (!inputText.trim() || !user || !currentChat) return;
    
    setSending(true);
    try {
      await dispatch(sendMessage({
        chatId: currentChat.id,
        senderId: user.id,
        text: inputText.trim(),
      })).unwrap();
      
      setInputText('');
      
      // Scroll to bottom after sending
      setTimeout(() => {
        if (flatListRef.current) {
          flatListRef.current.scrollToEnd({ animated: true });
        }
      }, 200);
    } catch (error) {
      console.error('Error sending message:', error);
      Alert.alert('Error', 'Failed to send message. Please try again.');
    } finally {
      setSending(false);
    }
  };

  // Render a message item
  const renderMessageItem = ({ item }: { item: Message }) => {
    const isOwnMessage = item.senderId === user?.id;
    const expirationHours = calculateExpirationTime(item.timestamp);
    
    return (
      <View
        style={[
          styles.messageContainer,
          isOwnMessage ? styles.ownMessageContainer : styles.otherMessageContainer,
        ]}
      >
        {!isOwnMessage && (
          <View style={styles.avatarContainer}>
            <Avatar
              uri={otherUser?.profileImage}
              initials={otherUser?.displayName}
              size="s"
            />
          </View>
        )}
        
        <View
          style={[
            styles.messageBubble,
            isOwnMessage ? styles.ownMessageBubble : styles.otherMessageBubble,
          ]}
        >
          <Text
            style={[
              styles.messageText,
              isOwnMessage ? styles.ownMessageText : styles.otherMessageText,
            ]}
          >
            {item.text}
          </Text>
          
          <View style={styles.messageFooter}>
            <Text
              style={[
                styles.messageTime,
                isOwnMessage ? styles.ownMessageTime : styles.otherMessageTime,
              ]}
            >
              {formatMessageTime(item.timestamp)}
            </Text>
            
            {/* Message expiration indicator */}
            <View style={styles.expirationContainer}>
              <Ionicons
                name="time-outline"
                size={12}
                color={
                  isOwnMessage
                    ? 'rgba(255, 255, 255, 0.7)'
                    : theme.colors.gray[500]
                }
              />
              <Text
                style={[
                  styles.expirationText,
                  isOwnMessage ? styles.ownMessageTime : styles.otherMessageTime,
                ]}
              >
                {expirationHours}h
              </Text>
            </View>
          </View>
        </View>
      </View>
    );
  };

  // If still loading the chat
  if (isLoading && !currentChat) {
    return <LoadingScreen message="Loading conversation..." />;
  }

  const chatMessages = currentChat && messages[currentChat.id] ? messages[currentChat.id] : [];

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <Header
        title={otherUser?.displayName || 'Chat'}
        subtitle={otherUser?.online ? 'Online' : 'Offline'}
        showBackButton
        onBackPress={() => navigation.goBack()}
        rightIcon="information-circle-outline"
        onRightPress={() => {
          if (otherUserId) {
            navigation.navigate(ROUTES.USER_PROFILE, { userId: otherUserId });
          }
        }}
      />
      
      {/* Expiration notice */}
      <View style={styles.noticeContainer}>
        <Ionicons name="time-outline" size={16} color={theme.colors.warning.dark} />
        <Text style={styles.noticeText}>
          Messages expire after {MESSAGE_EXPIRATION_HOURS} hours to encourage real-life meetings
        </Text>
      </View>
      
      {/* Messages list */}
      <FlatList
        ref={flatListRef}
        data={chatMessages}
        renderItem={renderMessageItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.messagesContainer}
        inverted={false}
        onContentSizeChange={() => {
          if (flatListRef.current && chatMessages.length > 0) {
            flatListRef.current.scrollToEnd({ animated: false });
          }
        }}
        ListEmptyComponent={
          <EmptyState
            title="No Messages Yet"
            message="Start the conversation by sending a message."
            icon="chatbubbles-outline"
          />
        }
      />
      
      {/* Input area */}
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
      >
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="Type a message..."
            value={inputText}
            onChangeText={setInputText}
            multiline
            maxLength={500}
          />
          
          <TouchableOpacity
            style={[
              styles.sendButton,
              (!inputText.trim() || sending) && styles.disabledSendButton,
            ]}
            onPress={handleSendMessage}
            disabled={!inputText.trim() || sending}
          >
            {sending ? (
              <ActivityIndicator size="small" color="#fff" />
            ) : (
              <Ionicons name="send" size={20} color="#fff" />
            )}
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.white,
  },
  noticeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.warning.light,
    paddingVertical: theme.spacing.s,
    paddingHorizontal: theme.spacing.m,
  },
  noticeText: {
    fontSize: theme.typography.fontSize.xs,
    color: theme.colors.warning.dark,
    marginLeft: theme.spacing.xs,
    flex: 1,
  },
  messagesContainer: {
    flexGrow: 1,
    padding: theme.spacing.m,
  },
  messageContainer: {
    flexDirection: 'row',
    marginBottom: theme.spacing.m,
    alignItems: 'flex-end',
  },
  ownMessageContainer: {
    justifyContent: 'flex-end',
  },
  otherMessageContainer: {
    justifyContent: 'flex-start',
  },
  avatarContainer: {
    marginRight: theme.spacing.s,
  },
  messageBubble: {
    maxWidth: '70%',
    borderRadius: theme.borders.radius.m,
    padding: theme.spacing.m,
  },
  ownMessageBubble: {
    backgroundColor: theme.colors.primary[600],
    borderBottomRightRadius: 0,
  },
  otherMessageBubble: {
    backgroundColor: theme.colors.gray[100],
    borderBottomLeftRadius: 0,
  },
  messageText: {
    fontSize: theme.typography.fontSize.m,
  },
  ownMessageText: {
    color: theme.colors.white,
  },
  otherMessageText: {
    color: theme.colors.gray[900],
  },
  messageFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: theme.spacing.xs,
  },
  messageTime: {
    fontSize: theme.typography.fontSize.xs,
  },
  ownMessageTime: {
    color: 'rgba(255, 255, 255, 0.7)',
  },
  otherMessageTime: {
    color: theme.colors.gray[500],
  },
  expirationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  expirationText: {
    fontSize: theme.typography.fontSize.xs,
    marginLeft: 2,
  },
  inputContainer: {
    flexDirection: 'row',
    padding: theme.spacing.m,
    borderTopWidth: 1,
    borderTopColor: theme.colors.gray[200],
    backgroundColor: theme.colors.white,
    alignItems: 'flex-end',
  },
  input: {
    flex: 1,
    backgroundColor: theme.colors.gray[100],
    borderRadius: theme.borders.radius.l,
    paddingHorizontal: theme.spacing.m,
    paddingVertical: theme.spacing.s,
    paddingTop: theme.spacing.s,
    paddingBottom: theme.spacing.s,
    maxHeight: 120,
    fontSize: theme.typography.fontSize.m,
  },
  sendButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: theme.colors.primary[600],
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: theme.spacing.s,
  },
  disabledSendButton: {
    backgroundColor: theme.colors.gray[300],
  },
});

export default ChatDetailScreen;
