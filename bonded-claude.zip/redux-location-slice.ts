import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import * as Location from 'expo-location';
import { doc, updateDoc, GeoPoint, serverTimestamp } from 'firebase/firestore';
import { firestore } from '../../services/firebase';
import { LocationState, GeoPoint as GeoPointType } from '../../types';
import { LOCATION_UPDATE_INTERVAL, LOCATION_DISTANCE_FILTER } from '../../constants';

// Initial state
const initialState: LocationState = {
  currentLocation: null,
  isLoading: false,
  error: null,
  isPermissionGranted: false,
  isLocationSharingEnabled: true,
};

// Request location permissions
export const requestLocationPermission = createAsyncThunk(
  'location/requestPermission',
  async (_, { rejectWithValue }) => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      return status === 'granted';
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Get current location
export const getCurrentLocation = createAsyncThunk(
  'location/getCurrent',
  async (_, { rejectWithValue, getState }) => {
    const state = getState() as { location: LocationState };
    
    if (!state.location.isPermissionGranted) {
      return rejectWithValue('Location permission not granted');
    }
    
    try {
      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });
      
      return {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      } as GeoPointType;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Watch user location changes
export const watchUserLocation = createAsyncThunk(
  'location/watch',
  async (userId: string | null, { dispatch, getState, rejectWithValue }) => {
    const state = getState() as { location: LocationState };
    
    if (!state.location.isPermissionGranted) {
      return rejectWithValue('Location permission not granted');
    }
    
    try {
      const locationSubscription = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.Balanced,
          distanceInterval: LOCATION_DISTANCE_FILTER,
          timeInterval: LOCATION_UPDATE_INTERVAL,
        },
        (location) => {
          const geoPoint: GeoPointType = {
            latitude: location.coords.latitude,
            longitude: location.coords.longitude,
          };
          
          dispatch(updateLocation(geoPoint));
          
          // Update user location in Firestore if user is logged in and location sharing is enabled
          if (userId && state.location.isLocationSharingEnabled) {
            dispatch(updateUserLocation({ userId, location: geoPoint }));
          }
        }
      );
      
      // Return a function to clean up the subscription
      return () => {
        if (locationSubscription) {
          locationSubscription.remove();
        }
      };
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Update user location in Firestore
export const updateUserLocation = createAsyncThunk(
  'location/updateUserLocation',
  async ({ userId, location }: { userId: string; location: GeoPointType }, { rejectWithValue, getState }) => {
    const state = getState() as { location: LocationState };
    
    if (!state.location.isLocationSharingEnabled) {
      return rejectWithValue('Location sharing is disabled');
    }
    
    try {
      const userRef = doc(firestore, 'users', userId);
      
      await updateDoc(userRef, {
        location: new GeoPoint(location.latitude, location.longitude),
        lastLocationUpdate: serverTimestamp(),
      });
      
      return location;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Location slice
const locationSlice = createSlice({
  name: 'location',
  initialState,
  reducers: {
    updateLocation: (state, action: PayloadAction<GeoPointType>) => {
      state.currentLocation = action.payload;
    },
    toggleLocationSharing: (state, action: PayloadAction<boolean>) => {
      state.isLocationSharingEnabled = action.payload;
    },
    clearLocationError: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    // Request location permission
    builder.addCase(requestLocationPermission.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(requestLocationPermission.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isPermissionGranted = action.payload;
    });
    builder.addCase(requestLocationPermission.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });
    
    // Get current location
    builder.addCase(getCurrentLocation.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(getCurrentLocation.fulfilled, (state, action) => {
      state.isLoading = false;
      state.currentLocation = action.payload;
    });
    builder.addCase(getCurrentLocation.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });
    
    // Watch user location
    builder.addCase(watchUserLocation.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(watchUserLocation.fulfilled, (state) => {
      state.isLoading = false;
    });
    builder.addCase(watchUserLocation.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload as string;
    });
    
    // Update user location in Firestore
    builder.addCase(updateUserLocation.rejected, (state, action) => {
      state.error = action.payload as string;
    });
  },
});

export const { updateLocation, toggleLocationSharing, clearLocationError } = locationSlice.actions;
export default locationSlice.reducer;
